def video_finished(status):
    if not status or not status.get("found"):
        return False
    duration = float(status.get("duration") or 0)
    current = float(status.get("currentTime") or 0)
    return bool(status.get("ended")) or (duration > 0 and current >= duration - 1.0)

def activity_looks_complete(page_text):
    text = (page_text or "").lower()
    phrases = [
        "activity complete", "lesson complete", "video completed",
        "you have completed this activity", "completion confirmed"
    ]
    return any(p in text for p in phrases)
