import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
CONFIG_PATH = ROOT / "config.json"
LOG_DIR = ROOT / "logs"
PROFILE_DIR = ROOT / "browser_profile"

DEFAULTS = {
    "community_campus_url": "",
    "navigation_delay_seconds": 3,
    "auto_continue": True,
    "auto_next": False,
    "early_next": False,
    "video_monitoring": True,
    "monitor_interval_seconds": 2,
    "ollama_model": "qwen2.5:7b",
    "ollama_url": "http://localhost:11434",
    "timer_default_minutes": 25,
    "accounts": [
        {"label": "Account 1", "profile": "account_1"},
        {"label": "Account 2", "profile": "account_2"}
    ]
}

def load_config():
    if not CONFIG_PATH.exists():
        save_config(DEFAULTS)
    try:
        data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        data = {}
    merged = DEFAULTS.copy()
    merged.update(data)
    return merged

def save_config(data):
    CONFIG_PATH.write_text(json.dumps(data, indent=2), encoding="utf-8")
