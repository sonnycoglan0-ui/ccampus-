import threading
import time

def blare_for_four_seconds():
    def worker():
        end = time.monotonic() + 4.0
        try:
            import winsound
            while time.monotonic() < end:
                winsound.Beep(1100, 250)
                time.sleep(.03)
        except Exception:
            # Fallback terminal bell, bounded to the same four-second window.
            while time.monotonic() < end:
                print("\a", end="", flush=True)
                time.sleep(.25)
    threading.Thread(target=worker, daemon=True).start()
