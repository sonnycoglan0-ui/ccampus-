import threading
import time
from datetime import timedelta

class WorkTimer:
    def __init__(self, on_complete=None):
        self.remaining = 0
        self.running = False
        self._paused = True
        self._stop = threading.Event()
        self._lock = threading.Lock()
        self.on_complete = on_complete
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def set_minutes(self, minutes):
        with self._lock:
            self.remaining = max(1, int(minutes)) * 60
            self.running = False
            self._paused = True

    def start(self):
        with self._lock:
            if self.remaining <= 0:
                self.remaining = 25 * 60
            self.running = True
            self._paused = False

    def pause(self):
        with self._lock:
            self._paused = True

    def resume(self):
        with self._lock:
            if self.remaining > 0:
                self.running = True
                self._paused = False

    def reset(self):
        with self._lock:
            self.running = False
            self._paused = True
            self.remaining = 0

    def display(self):
        with self._lock:
            seconds = self.remaining
            active = self.running and not self._paused
        return f"{seconds // 60:02d}:{seconds % 60:02d}" + (" RUNNING" if active else " PAUSED/STOPPED")

    def _run(self):
        last = time.monotonic()
        while not self._stop.is_set():
            time.sleep(.2)
            now = time.monotonic()
            elapsed = now - last
            last = now
            completed = False
            with self._lock:
                if self.running and not self._paused and self.remaining > 0:
                    self.remaining = max(0, self.remaining - elapsed)
                    if self.remaining <= 0:
                        self.running = False
                        self._paused = True
                        completed = True
            if completed and self.on_complete:
                self.on_complete()
