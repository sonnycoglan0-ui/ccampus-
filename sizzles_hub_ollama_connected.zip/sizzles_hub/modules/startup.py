import random
import time
from modules.terminal import clear, RED, CYAN, WHITE, RESET

LOGO = [
"  ███████╗██╗███████╗███████╗██╗     ███████╗███████╗",
"  ██╔════╝██║╚══███╔╝╚══███╔╝██║     ██╔════╝██╔════╝",
"  ███████╗██║  ███╔╝  ███╔╝ ██║     █████╗  ███████╗",
"  ╚════██║██║ ███╔╝  ███╔╝  ██║     ██╔══╝  ╚════██║",
"  ███████║██║███████╗███████╗███████╗███████╗███████║",
"  ╚══════╝╚═╝╚══════╝╚══════╝╚══════╝╚══════╝╚══════╝"
]

def play_startup():
    clear()
    for _ in range(7):
        clear()
        for line in LOGO:
            print((RED if random.random() > .5 else CYAN) + line + RESET)
        time.sleep(.07)
    clear()
    for line in LOGO:
        print(CYAN + line + RESET)
        time.sleep(.045)
    print()
    print(WHITE + "              COMMUNITY CAMPUS COMMAND CENTRE" + RESET)
    time.sleep(.35)
    print("              Initialising modules", end="", flush=True)
    for _ in range(3):
        time.sleep(.25)
        print(".", end="", flush=True)
    time.sleep(.3)
