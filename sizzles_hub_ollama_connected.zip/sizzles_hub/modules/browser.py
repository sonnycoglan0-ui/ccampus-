import threading
from pathlib import Path
from modules.settings import PROFILE_DIR
from modules.terminal import log

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    sync_playwright = None

class CampusBrowser:
    def __init__(self):
        self.playwright = None
        self.context = None
        self.page = None
        self.account = None
        self._lock = threading.RLock()

    def open(self, account, url):
        if sync_playwright is None:
            raise RuntimeError("Playwright is missing. Run: pip install -r requirements.txt")
        self.close()
        profile = PROFILE_DIR / account
        profile.mkdir(parents=True, exist_ok=True)
        self.playwright = sync_playwright().start()
        self.context = self.playwright.chromium.launch_persistent_context(
            user_data_dir=str(profile),
            headless=False,
            viewport={"width": 1280, "height": 850}
        )
        self.page = self.context.pages[0] if self.context.pages else self.context.new_page()
        self.account = account
        if url:
            self.page.goto(url, wait_until="domcontentloaded", timeout=60000)
        log(f"Opened browser profile {account}; login is manual.")
        return self.page

    def close(self):
        with self._lock:
            try:
                if self.context:
                    self.context.close()
            except Exception:
                pass
            try:
                if self.playwright:
                    self.playwright.stop()
            except Exception:
                pass
            self.context = self.page = self.playwright = None
            self.account = None

    def connected(self):
        return self.page is not None

    def snapshot(self):
        if not self.page:
            return {"title": "No browser", "url": "", "text": ""}
        try:
            return {
                "title": self.page.title(),
                "url": self.page.url,
                "text": self.page.locator("body").inner_text(timeout=3000)[:12000]
            }
        except Exception as exc:
            return {"title": "Unavailable", "url": "", "text": str(exc)}

    def session_expired(self):
        text = self.snapshot().get("text", "").lower()
        signals = [
            "your session has expired", "session expired", "please log in again",
            "please login again", "sign in to continue", "you have been logged out"
        ]
        return any(s in text for s in signals)

    def video_status(self):
        if not self.page:
            return {"found": False}
        try:
            return self.page.evaluate("""() => {
              const v = document.querySelector('video');
              if (!v) return {found:false};
              return {found:true, currentTime:v.currentTime || 0,
                duration:Number.isFinite(v.duration) ? v.duration : 0,
                paused:v.paused, ended:v.ended, readyState:v.readyState};
            }""")
        except Exception:
            return {"found": False}

    def activity_text(self):
        return self.snapshot().get("text", "")
