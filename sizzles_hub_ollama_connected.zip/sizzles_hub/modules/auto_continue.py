import threading
import time
from modules.completion import video_finished, activity_looks_complete
from modules.navigation import click_after_completion
from modules.alarm import blare_for_four_seconds
from modules.terminal import log

class CampusMonitor:
    def __init__(self, browser, config, state):
        self.browser = browser
        self.config = config
        self.state = state
        self.enabled = False
        self._thread = None
        self._last_navigation_key = None
        self._session_alerted = False

    def start(self):
        if self.enabled:
            return
        self.enabled = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()

    def stop(self):
        self.enabled = False

    def _loop(self):
        while self.enabled:
            try:
                if not self.browser.connected():
                    self.state["automation"] = "Waiting for browser"
                    time.sleep(1)
                    continue

                if self.browser.session_expired():
                    self.state["automation"] = "Paused — session expired; log in manually"
                    if not self._session_alerted:
                        blare_for_four_seconds()
                        self._session_alerted = True
                        log("Session expiry detected; automation paused for manual login.")
                    time.sleep(2)
                    continue
                else:
                    self._session_alerted = False

                page = self.browser.page
                status = self.browser.video_status() if self.config.get("video_monitoring", True) else {"found": False}
                if status.get("found"):
                    duration = status.get("duration", 0)
                    current = status.get("currentTime", 0)
                    self.state["video"] = (
                        f"{current:.0f}s / {duration:.0f}s "
                        f"({'paused' if status.get('paused') else 'playing'})"
                    )
                else:
                    self.state["video"] = "No video detected"

                body = self.browser.activity_text()
                complete = video_finished(status) or activity_looks_complete(body)
                if complete and self.config.get("auto_continue", True):
                    key = (self.browser.account, page.url, round(status.get("duration", 0)))
                    if key != self._last_navigation_key:
                        self._last_navigation_key = key
                        self.state["automation"] = "Completion detected; checking navigation"
                        ok, message = click_after_completion(
                            page,
                            self.config.get("navigation_delay_seconds", 3),
                            allow_next=bool(self.config.get("auto_next", False))
                        )
                        self.state["automation"] = message
                        log(message)
                else:
                    self.state["automation"] = "Monitoring activity"
            except Exception as exc:
                self.state["automation"] = f"Recovering from error: {exc}"
                log(f"Monitor error: {exc}")
            time.sleep(max(1, int(self.config.get("monitor_interval_seconds", 2))))
