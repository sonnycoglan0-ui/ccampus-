"""Local study assistant powered by an Ollama model."""

import requests


def ask_local_ai(question, options=None, model="qwen2.5:7b",
                 base_url="http://localhost:11434"):
    question = (question or "").strip()
    if not question:
        return "Please enter a question after AI ASSESS,."

    base_url = (base_url or "http://localhost:11434").rstrip("/")
    model = (model or "qwen2.5:7b").strip()
    option_text = ""
    if options:
        option_text = "\nAnswer options:\n" + "\n".join(f"- {x}" for x in options)

    prompt = (
        "You are a clear, supportive study assistant. Help the student understand "
        "the question and explain the reasoning. Be accurate, concise, and say "
        "when you are unsure. Do not interact with the learning platform.\n\n"
        f"Question: {question}{option_text}\n\n"
        "Give the answer, then a short explanation."
    )

    try:
        response = requests.post(
            f"{base_url}/api/generate",
            json={"model": model, "prompt": prompt, "stream": False},
            timeout=(5, 180),
        )
        if response.status_code == 404:
            return (
                f"Model '{model}' was not found in Ollama.\n"
                f"Open CMD and run: ollama pull {model}"
            )
        response.raise_for_status()
        data = response.json()
        answer = data.get("response", "").strip()
        return answer or "Ollama responded, but the model returned an empty answer."
    except requests.exceptions.ConnectionError:
        return (
            "Couldn't reach Ollama at " + base_url + ".\n"
            "Make sure the Ollama app is running, then try again."
        )
    except requests.exceptions.Timeout:
        return "Ollama took too long to respond. Try again in a moment."
    except (requests.RequestException, ValueError) as exc:
        return f"Local AI request failed: {exc}"
