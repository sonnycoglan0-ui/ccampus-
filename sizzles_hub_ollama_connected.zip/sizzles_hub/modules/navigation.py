import time
from modules.terminal import log

BUTTON_NAMES = ["Next", "Finish Topic", "Continue"]

def find_navigation_button(page):
    # Search accessible buttons and links by exact/contained visible labels.
    for name in BUTTON_NAMES:
        candidates = page.get_by_role("button", name=name, exact=True)
        try:
            if candidates.count() and candidates.first.is_visible() and candidates.first.is_enabled():
                return candidates.first, name
        except Exception:
            pass
        candidates = page.get_by_role("link", name=name, exact=True)
        try:
            if candidates.count() and candidates.first.is_visible():
                return candidates.first, name
        except Exception:
            pass
    return None, None

def click_after_completion(page, delay_seconds=3, allow_next=False):
    button, name = find_navigation_button(page)
    if not button:
        return False, "No navigation button found."
    if name == "Next" and not allow_next:
        return False, "Next is disabled by default in settings."
    time.sleep(max(0, float(delay_seconds)))
    try:
        button.click(timeout=5000)
        log(f"Clicked {name} after completion confirmation.")
        # Confirm that page/activity changes before allowing another click.
        page.wait_for_timeout(1200)
        return True, f"Clicked {name}; checking that the next activity loaded."
    except Exception as exc:
        return False, f"Navigation click failed: {exc}"
