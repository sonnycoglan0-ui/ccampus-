# SC HUB 2.1 — Python CMD port of SC Hub Edge v1.5.0

This project ports the original extension's core video/navigation behaviour into a Windows CMD Python application.

## Install
```bat
py -m pip install -r requirements.txt
py -m playwright install chromium
py sc_hub.py
```

## Use
1. Choose **1** to launch the persistent Chromium profile.
2. Sign into Community Campus normally and open a learning activity.
3. Choose **2** to start monitoring.
4. Auto-Continue is enabled by default; toggle it with menu option 3 or 4.
5. Use Configuration to change delay, Auto-Play, Auto-Next and optional Early Next.

## Ported from the original SC Hub Edge v1.5.0
- Scans all Playwright-accessible frames.
- Recursively scans open Shadow DOM roots for HTML5 video elements and navigation controls.
- Reads currentTime, duration, paused and ended.
- Attempts Auto-Play once per video source when enabled and paused.
- Waits for the genuine ended state before standard Auto-Continue.
- Applies the configured delay and retries looking for navigation for up to 30 seconds.
- Navigation priority: Next, Finish Topic, Continue.
- Optional Early Next mode clicks an available visible/enabled matching control without waiting for video end, mirroring the extension's separate opt-in mode.
- Manual Continue is guarded until a video reports ended.

## Notes
- Playwright can inspect cross-origin frames that are attached to the opened page, but browser/player restrictions can still prevent access to some content.
- Only open Shadow DOM roots are searchable; closed shadow roots cannot be inspected.
- Some custom video players do not expose an HTML5 `<video>` element. Those need a site-specific adapter.
- Autoplay may be blocked by browser policy; in that case press Play yourself.
- This is a local browser helper. It does not bypass login, access controls, or course requirements.
- Logs: `logs/sc_hub.log`; persistent browser profile: `browser_profile/`.
