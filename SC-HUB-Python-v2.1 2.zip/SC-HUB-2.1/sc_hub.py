from modules.terminal import banner, main_menu, status_panel, choose
from modules.settings import load_config, save_config, configure
from modules.browser import BrowserWorker
from pathlib import Path
import queue, time

def main():
    config=load_config(); commands=queue.Queue(); worker=BrowserWorker(config,commands)
    banner()
    while True:
        status=worker.get_status(); status_panel(status); main_menu(); choice=choose()
        if choice=="1":
            if not worker.is_alive(): worker.start()
            commands.put(("connect",None))
            print("\\n[SC HUB] Opening Chromium. Sign in normally and open your course.")
        elif choice=="2":
            if not worker.is_alive(): worker.start(); commands.put(("connect",None))
            commands.put(("monitor",True)); print("\\n[SC HUB] Monitoring started.")
        elif choice=="3":
            config["auto_continue"]=True; save_config(config); worker.update_config(config)
            print("\\n[SC HUB] Auto-Continue ENABLED.")
        elif choice=="4":
            config["auto_continue"]=False; save_config(config); worker.update_config(config)
            print("\\n[SC HUB] Auto-Continue DISABLED.")
        elif choice=="5":
            commands.put(("manual_continue",None)); print("\\n[SC HUB] Manual Continue requested.")
        elif choice=="6": status_panel(worker.get_status(),full=True)
        elif choice=="7":
            config=configure(config); save_config(config); worker.update_config(config)
        elif choice=="8":
            p=Path("logs/sc_hub.log"); print("\\n--- RECENT LOGS ---")
            if p.exists(): print("\\n".join(p.read_text(encoding="utf-8",errors="replace").splitlines()[-30:]))
            else: print("No logs yet.")
        elif choice=="9":
            commands.put(("stop_monitor",None)); print("\\n[SC HUB] Monitoring stopped.")
        elif choice=="0":
            if worker.is_alive(): commands.put(("shutdown",None)); worker.join(timeout=5)
            print("\\n[SC HUB] Goodbye."); break
        else: print("\\n[SC HUB] Invalid option.")
        input("\\nPress Enter to return to menu...")
if __name__=="__main__": main()
