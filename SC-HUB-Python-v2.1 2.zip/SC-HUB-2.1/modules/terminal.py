import os
from datetime import datetime

CYAN = "\033[96m"; MAGENTA = "\033[95m"; GREEN = "\033[92m"
YELLOW = "\033[93m"; WHITE = "\033[97m"; RESET = "\033[0m"

def banner():
    os.system("")
    os.system("cls" if os.name == "nt" else "clear")
    print(CYAN + r"""
  ███████╗ ██████╗    ██╗  ██╗██╗   ██╗██████╗
  ██╔════╝██╔════╝    ██║  ██║██║   ██║██╔══██╗
  ███████╗██║         ███████║██║   ██║██████╔╝
  ╚════██║██║         ██╔██║   ██║██║  ██║
  ███████║╚██████╗    ██║  ██║╚██████╔╝██████╔╝
  ╚══════╝ ╚═════╝    ╚═╝  ╚═╝ ╚═════╝
""" + RESET)
    print(MAGENTA + "             COMMUNITY CAMPUS AUTOMATION\n" + RESET)

def status_panel(s, full=False):
    print(CYAN + "  ┌────────────── SC HUB STATUS ──────────────┐" + RESET)
    def v(k, default="UNKNOWN"): return s.get(k, default)
    print(f"  Version       : {WHITE}2.1.0{RESET}")
    for label, key in [("Connection","connection"),("Browser","browser"),("Monitoring","monitoring"),
                       ("Auto-Continue","auto_continue"),("Auto-Next","auto_next"),
                       ("Auto-Play","auto_play"),("Early Next","early_next")]:
        value = v(key)
        colour = GREEN if value in ("CONNECTED","RUNNING","ACTIVE","ENABLED","ON") else YELLOW
        print(f"  {label:<14}: {colour}{value}{RESET}")
    print(f"  Date/Time     : {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    print("  " + "─" * 43)
    if full:
        for label,key in [("Page","page"),("Video","video_title"),("Progress","progress"),
                          ("Playback","playback"),("Completion","completion"),
                          ("Frame","frame"),("Navigation","navigation"),("Last action","last_action")]:
            print(f"  {label:<14}: {v(key, 'N/A')}")
    print(CYAN + "  └───────────────────────────────────────────┘" + RESET)

def main_menu():
    print("""
  [1] Connect to Community Campus
  [2] Start Video Monitoring
  [3] Enable Auto-Continue
  [4] Disable Auto-Continue
  [5] Manual Continue
  [6] View Current Video Information
  [7] Configuration
  [8] View Activity Logs
  [9] Stop Automation
  [0] Exit
""")
def choose():
    return input("Select an option [0-9]: ").strip()
