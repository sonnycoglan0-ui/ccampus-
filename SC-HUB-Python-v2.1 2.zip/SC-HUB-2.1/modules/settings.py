import json
from pathlib import Path

CONFIG_PATH = Path("config.json")
DEFAULTS = {
    "auto_continue": True,
    "auto_next": True,
    "auto_play": True,
    "early_next": False,
    "navigation_delay_seconds": 4,
    "monitor_interval_seconds": 1,
    "browser_profile": "browser_profile",
    "log_level": "INFO"
}

def load_config():
    if CONFIG_PATH.exists():
        try:
            data = json.loads(CONFIG_PATH.read_text(encoding="utf-8"))
            return {**DEFAULTS, **data}
        except (json.JSONDecodeError, OSError):
            pass
    save_config(DEFAULTS.copy())
    return DEFAULTS.copy()

def save_config(config):
    CONFIG_PATH.write_text(json.dumps(config, indent=2), encoding="utf-8")

def configure(config):
    while True:
        print("\\n--- CONFIGURATION ---")
        print(f"[1] Navigation delay: {config['navigation_delay_seconds']} seconds")
        print(f"[2] Monitor interval: {config['monitor_interval_seconds']} seconds")
        print(f"[3] Auto-Next: {'ON' if config['auto_next'] else 'OFF'}")
        print(f"[4] Auto-Play: {'ON' if config['auto_play'] else 'OFF'}")
        print(f"[5] Early Next: {'ON' if config['early_next'] else 'OFF'}")
        print("[0] Back")
        choice = input("Select setting: ").strip()
        if choice == "0":
            return config
        elif choice == "1":
            try:
                config["navigation_delay_seconds"] = max(0, min(60, int(input("Delay (0-60 seconds): "))))
            except ValueError:
                print("Enter a whole number.")
        elif choice == "2":
            try:
                config["monitor_interval_seconds"] = max(1, min(5, int(input("Refresh interval (1-5 seconds): "))))
            except ValueError:
                print("Enter a whole number.")
        elif choice in {"3", "4", "5"}:
            key = {"3": "auto_next", "4": "auto_play", "5": "early_next"}[choice]
            config[key] = not config[key]
            print(f"{key.replace('_', ' ').title()} is now {'ON' if config[key] else 'OFF'}.")
        save_config(config)
