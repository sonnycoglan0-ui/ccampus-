import logging, queue, threading, time
from pathlib import Path

try:
    from playwright.sync_api import sync_playwright
except ImportError:
    sync_playwright = None

Path("logs").mkdir(exist_ok=True)
logging.basicConfig(filename="logs/sc_hub.log", level=logging.INFO,
    format="%(asctime)s | %(levelname)s | %(message)s", encoding="utf-8")
log = logging.getLogger("SC-HUB")

# Same discovery strategy as the original extension:
# document + recursively-open Shadow DOM roots, visible/enabled navigation labels,
# and a scan of every browser frame.
VIDEO_SCAN_JS = r"""
() => {
  const found = new Set(), roots = [document], seen = new Set();
  while (roots.length) {
    const root = roots.pop();
    if (!root || seen.has(root) || !root.querySelectorAll) continue;
    seen.add(root);
    try {
      root.querySelectorAll('video').forEach(v => found.add(v));
      root.querySelectorAll('*').forEach(e => { if (e.shadowRoot) roots.push(e.shadowRoot); });
    } catch (_) {}
  }
  const visible = [...found].filter(v => {
    if (!v.isConnected || !v.getClientRects().length) return false;
    const s = getComputedStyle(v);
    return s.display !== 'none' && s.visibility !== 'hidden' && s.opacity !== '0';
  });
  return visible.map(v => ({
    current: Number.isFinite(v.currentTime) ? v.currentTime : null,
    duration: Number.isFinite(v.duration) ? v.duration : null,
    ended: !!v.ended, paused: !!v.paused, playing: !v.paused && !v.ended,
    source: v.currentSrc || v.src || '',
    title: v.getAttribute('aria-label') || v.getAttribute('title') || '',
    ready: v.readyState
  }));
}
"""

AUTOPLAY_JS = r"""
() => {
 const roots=[document], seen=new Set(), videos=[];
 while(roots.length){const r=roots.pop();if(!r||seen.has(r)||!r.querySelectorAll)continue;seen.add(r);
  try{r.querySelectorAll('video').forEach(v=>videos.push(v));r.querySelectorAll('*').forEach(e=>{if(e.shadowRoot)roots.push(e.shadowRoot)});}catch(_){}}
 const v=videos.find(x=>x.getClientRects().length&&!x.ended&&x.paused);
 if(!v) return {attempted:false};
 try { const p=v.play(); if(p&&p.catch)p.catch(()=>{}); return {attempted:true,source:v.currentSrc||v.src||''}; }
 catch(e){return {attempted:true,error:e.name||String(e)};}
}
"""

FIND_CLICK_JS = r"""
() => {
 const roots=[document], seen=new Set(), els=[];
 while(roots.length){const r=roots.pop();if(!r||seen.has(r)||!r.querySelectorAll)continue;seen.add(r);
  try{
   r.querySelectorAll('button,a,[role="button"],input[type="button"],input[type="submit"]').forEach(e=>els.push(e));
   r.querySelectorAll('*').forEach(e=>{if(e.shadowRoot)roots.push(e.shadowRoot)});
  }catch(_){}
 }
 const excluded='dialog,[role="dialog"],[aria-modal="true"],.modal,.modal-dialog,.swal2-container,.bootbox,[aria-hidden="true"]';
 const label=e=>(e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'').replace(/\s+/g,' ').trim().toLowerCase();
 const eligible=e=>{
  if(!e.getClientRects().length||e.disabled||e.getAttribute('aria-disabled')==='true'||e.closest(excluded))return false;
  const s=getComputedStyle(e);return s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0';
 };
 for(const name of ['next','finish topic','continue']){
  const e=els.find(x=>eligible(x)&&label(x)===name);
  if(e){e.click();return {clicked:true,label:name};}
 }
 return {clicked:false,label:''};
}
"""

class BrowserWorker(threading.Thread):
    def __init__(self, config, commands):
        super().__init__(daemon=True)
        self.config = dict(config); self.commands = commands
        self.lock = threading.Lock(); self.running = True; self.monitoring = False
        self.pw = None; self.context = None; self.last_video_key = None
        self.ended_key = None; self.navigation_due = None; self.retry_until = None
        self.last_early_signature = None; self.last_autoplay_source = {}
        self.status = {}
        self._refresh_flags()

    def _refresh_flags(self):
        self._set(auto_continue="ENABLED" if self.config.get("auto_continue") else "DISABLED",
                  auto_next="ENABLED" if self.config.get("auto_next", True) else "DISABLED",
                  auto_play="ENABLED" if self.config.get("auto_play", True) else "DISABLED",
                  early_next="ON" if self.config.get("early_next") else "OFF")

    def _set(self, **kw):
        with self.lock: self.status.update(kw)

    def get_status(self):
        with self.lock: return dict(self.status)

    def update_config(self, config):
        self.config = dict(config); self._refresh_flags()

    def run(self):
        if sync_playwright is None:
            self._set(last_action="Playwright missing. Install requirements.")
            return
        try:
            self.pw = sync_playwright().start()
            while self.running:
                self._commands()
                if self.context:
                    if self.monitoring: self._scan()
                    else: self._refresh_page()
                time.sleep(max(.5, float(self.config.get("monitor_interval_seconds", 1))))
        except Exception as e:
            log.exception("Worker failure")
            self._set(last_action=f"Worker error: {e}")
        finally:
            try:
                if self.context: self.context.close()
                if self.pw: self.pw.stop()
            except Exception: pass
            self._set(browser="STOPPED", monitoring="INACTIVE")

    def _commands(self):
        while True:
            try: cmd, payload = self.commands.get_nowait()
            except queue.Empty: break
            if cmd == "connect": self._connect()
            elif cmd == "monitor":
                self.monitoring = bool(payload)
                self._set(monitoring="ACTIVE" if self.monitoring else "INACTIVE")
                log.info("Monitoring %s", self.monitoring)
            elif cmd == "stop_monitor":
                self.monitoring = False; self.navigation_due = None; self.retry_until = None
                self._set(monitoring="INACTIVE", last_action="Monitoring stopped.")
            elif cmd == "manual_continue": self._manual_continue()
            elif cmd == "shutdown": self.running = False

    def _connect(self):
        if self.context:
            self._set(connection="CONNECTED", browser="RUNNING", last_action="Browser already connected.")
            return
        try:
            profile = Path(self.config.get("browser_profile","browser_profile")); profile.mkdir(exist_ok=True)
            self.context = self.pw.chromium.launch_persistent_context(str(profile.resolve()), headless=False)
            if not self.context.pages: self.context.new_page()
            self._set(connection="CONNECTED", browser="RUNNING",
                      last_action="Chromium opened. Sign in normally and open your course.")
            log.info("Persistent browser launched.")
        except Exception as e:
            self._set(connection="DISCONNECTED", browser="STOPPED", last_action=f"Browser launch failed: {e}")
            log.exception("Launch failed")

    def _pages(self):
        return [p for p in self.context.pages if not p.is_closed()] if self.context else []

    def _refresh_page(self):
        pages=self._pages()
        if pages:
            p=pages[-1]
            try: self._set(connection="CONNECTED",browser="RUNNING",page=(p.title() or p.url)[:120])
            except Exception: pass

    @staticmethod
    def _fmt(v):
        if v is None: return "--:--"
        v=max(0,int(v)); return f"{v//60:02d}:{v%60:02d}"

    def _all_videos(self, page):
        result=[]
        for index, frame in enumerate(page.frames):
            try:
                for item in frame.evaluate(VIDEO_SCAN_JS):
                    item["frame_index"]=index
                    result.append((frame,item))
            except Exception:
                continue
        return result

    def _find_and_click(self, page):
        # Search each frame, using the extension's label priority.
        for index, frame in enumerate(page.frames):
            try:
                result=frame.evaluate(FIND_CLICK_JS)
                if result.get("clicked"):
                    return result["label"], index
            except Exception:
                continue
        return None, None

    def _scan(self):
        pages=self._pages()
        if not pages:
            self._set(connection="DISCONNECTED",last_action="No browser page is open.")
            return
        page=pages[-1]
        try:
            self._set(connection="CONNECTED",browser="RUNNING",page=(page.title() or page.url)[:120])
            videos=self._all_videos(page)
            if not videos:
                self._set(video_title="No video detected in accessible frames/shadow roots",
                          progress="--:-- / --:--",playback="NO VIDEO FOUND",
                          completion="NOT CONFIRMED",frame="--",navigation="Not detected")
                return

            # Match extension selection: first not-ended video, else last video.
            chosen=next((x for x in videos if not x[1]["ended"]),videos[-1])
            frame,data=chosen
            key=(page.url,data.get("source",""),round(data.get("duration") or 0,2),chosen[1]["frame_index"])
            title=data.get("title") or page.title() or "Untitled video"
            cur=data.get("current"); dur=data.get("duration")
            pct=f"{cur/dur*100:.0f}%" if cur is not None and dur and dur>0 else "N/A"
            playback="Finished" if data["ended"] else ("Paused" if data["paused"] else "Playing")
            self._set(video_title=title[:100],progress=f"{self._fmt(cur)} / {self._fmt(dur)} ({pct})",
                      playback=playback,completion="CONFIRMED" if data["ended"] else "NOT CONFIRMED",
                      frame=f"Frame {data['frame_index']}",navigation="Scanning controls")

            # Original extension's Auto-Play behaviour: try once per source while paused.
            if self.config.get("auto_play",True) and data["paused"] and not data["ended"]:
                source=data.get("source") or "(source pending)"
                if self.last_autoplay_source.get(data["frame_index"]) != source:
                    try:
                        result=frame.evaluate(AUTOPLAY_JS)
                        if result.get("attempted"):
                            self.last_autoplay_source[data["frame_index"]]=source
                            self._set(last_action="Auto-Play attempted for the visible video.")
                    except Exception: pass

            # Optional Early Next mode from the extension: click only a visible, enabled
            # page-provided Next/Finish Topic/Continue control.
            if self.config.get("early_next") and self.config.get("auto_next",True):
                label,frame_idx=self._find_and_click(page)
                if label:
                    signature=(page.url,data.get("source",""),label)
                    if signature != self.last_early_signature:
                        self.last_early_signature=signature
                        self._set(navigation=label,last_action=f"Early Next clicked: {label}")
                        log.info("Early Next clicked: %s",label)
                        self.ended_key=None; self.navigation_due=None; self.retry_until=None
                        return

            if data["ended"]:
                if self.ended_key != key:
                    self.ended_key=key
                    delay=float(self.config.get("navigation_delay_seconds",4))
                    self.navigation_due=time.monotonic()+delay
                    self.retry_until=self.navigation_due+30
                    self._set(last_action=f"Video ended. Waiting {delay:g}s before Auto-Continue.")
                    log.info("Video ended; configured delay started.")
                if (self.navigation_due is not None and time.monotonic()>=self.navigation_due
                    and self.config.get("auto_continue") and self.config.get("auto_next",True)):
                    label,frame_idx=self._find_and_click(page)
                    if label:
                        self._set(navigation=label,last_action=f"Auto-Continue clicked: {label}")
                        log.info("Auto-Continue clicked %s in frame %s",label,frame_idx)
                        self.ended_key=None; self.navigation_due=None; self.retry_until=None
                        self.last_early_signature=None
                    elif self.retry_until and time.monotonic()<self.retry_until:
                        self._set(navigation="Waiting for Next/Continue button")
                    else:
                        self._set(navigation="No eligible navigation button found",
                                  last_action="Video ended, but no supported navigation button appeared.")
                        self.navigation_due=None; self.retry_until=None
            else:
                self._set(navigation="Ready controls detected" if self._has_target(page) else "None detected")
                # A reused video element/source changing cancels a stale completion retry.
                if self.ended_key and key != self.ended_key:
                    self.ended_key=None; self.navigation_due=None; self.retry_until=None
        except Exception as e:
            self._set(last_action=f"Monitoring error: {e}")
            log.exception("Scan failed")

    def _has_target(self,page):
        for frame in page.frames:
            try:
                r=frame.evaluate("""() => {
                 const roots=[document],seen=new Set(),els=[];
                 while(roots.length){const r=roots.pop();if(!r||seen.has(r)||!r.querySelectorAll)continue;seen.add(r);
                  try{r.querySelectorAll('button,a,[role="button"],input[type="button"],input[type="submit"]').forEach(e=>els.push(e));
                  r.querySelectorAll('*').forEach(e=>{if(e.shadowRoot)roots.push(e.shadowRoot)});}catch(_){}}
                 return els.some(e=>{const t=(e.innerText||e.value||e.getAttribute('aria-label')||e.getAttribute('title')||'').replace(/\\s+/g,' ').trim().toLowerCase();
                  const s=getComputedStyle(e);return ['next','finish topic','continue'].includes(t)&&e.getClientRects().length&&!e.disabled&&e.getAttribute('aria-disabled')!=='true'&&s.display!=='none'&&s.visibility!=='hidden'&&s.opacity!=='0';});
                }""")
                if r:return True
            except Exception:pass
        return False

    def _manual_continue(self):
        pages=self._pages()
        if not pages:
            self._set(last_action="Connect to the browser first."); return
        page=pages[-1]
        videos=self._all_videos(page)
        if not any(item.get("ended") for _,item in videos):
            self._set(last_action="Manual Continue unavailable: the current video has not ended.")
            return
        label,idx=self._find_and_click(page)
        if label:
            self._set(navigation=label,last_action=f"Manual Continue clicked: {label}")
            log.info("Manual Continue clicked %s",label)
        else:
            self._set(last_action="Video ended, but no eligible Next/Continue control was found.")

