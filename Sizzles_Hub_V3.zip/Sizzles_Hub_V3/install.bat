@echo off
title Sizzles Hub V3 Installer
python -m pip install --upgrade pip
python -m pip install -r requirements.txt
python -m playwright install chromium
echo.
echo Sizzles Hub V3 dependencies installed.
pause
