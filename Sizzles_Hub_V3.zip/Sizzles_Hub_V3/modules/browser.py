import asyncio, threading
from pathlib import Path
from playwright.async_api import async_playwright
from .settings import ROOT

class CampusBrowser:
    def __init__(self, config, logger, on_status=None, on_expired=None):
        self.config = config
        self.logger = logger
        self.on_status = on_status or (lambda s: None)
        self.on_expired = on_expired or (lambda: None)
        self.loop = None
        self.thread = None
        self.ready = threading.Event()
        self.error = None
        self.page = None
        self.context = None
        self.playwright = None
        self.running = False

    def start(self):
        if self.thread and self.thread.is_alive():
            return
        self.thread = threading.Thread(target=self._thread_main, daemon=True)
        self.thread.start()
        self.ready.wait(15)

    def _thread_main(self):
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)
        try:
            self.loop.run_until_complete(self._launch())
            self.loop.run_forever()
        except Exception as exc:
            self.error = str(exc)
            self.logger.exception("Browser startup failed")
        finally:
            try:
                self.loop.run_until_complete(self._shutdown())
            except Exception:
                pass

    async def _launch(self):
        self.playwright = await async_playwright().start()
        profile = ROOT / "browser_profile"
        profile.mkdir(exist_ok=True)
        opts = self.config["browser"]
        self.context = await self.playwright.chromium.launch_persistent_context(
            user_data_dir=str(profile),
            headless=bool(opts.get("headless", False)),
            slow_mo=int(opts.get("slow_mo_ms", 80)),
            args=["--start-maximized"]
        )
        self.context.set_default_navigation_timeout(int(opts.get("navigation_timeout_ms", 30000)))
        self.page = self.context.pages[0] if self.context.pages else await self.context.new_page()
        self.page.on("framenavigated", lambda frame: self.logger.info(f"Navigated: {frame.url}") if frame == self.page.main_frame else None)
        self.running = True
        self.on_status("Chromium connected")
        self.ready.set()
        url = self.config.get("campus_url", "").strip()
        if url:
            await self._navigate(url)
        else:
            self.on_status("Chromium ready — set campus_url in config.json")

    async def _navigate(self, url):
        if not url.startswith(("https://", "http://")):
            raise ValueError("Campus URL must begin with https:// or http://")
        await self.page.goto(url, wait_until="domcontentloaded")
        self.on_status(f"Opened: {self.page.url}")
        self.logger.info(f"Opened campus URL: {self.page.url}")

    def navigate(self, url):
        if not self.loop or not self.running:
            self.start()
        if not self.loop or not self.running:
            print(f"Browser unavailable: {self.error or 'startup timed out'}")
            return
        future = asyncio.run_coroutine_threadsafe(self._navigate(url), self.loop)
        try:
            future.result(timeout=40)
        except Exception as exc:
            self.logger.exception("Navigation failed")
            print(f"Navigation failed: {exc}")

    async def _shutdown(self):
        if self.context:
            await self.context.close()
        if self.playwright:
            await self.playwright.stop()

    def stop(self):
        if self.loop and self.loop.is_running():
            asyncio.run_coroutine_threadsafe(self._shutdown(), self.loop).result(timeout=10)
            self.loop.call_soon_threadsafe(self.loop.stop)
        self.running = False
        self.on_status("Browser closed")
