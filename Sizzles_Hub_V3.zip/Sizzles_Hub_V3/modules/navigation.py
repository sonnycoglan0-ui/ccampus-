import asyncio

BUTTON_LABELS = [
    "Finish Topic", "Finish topic", "Next", "Continue", "Continue learning"
]

async def find_navigation_button(page):
    for label in BUTTON_LABELS:
        candidates = page.get_by_role("button", name=label, exact=True)
        try:
            count = await candidates.count()
            for i in range(min(count, 5)):
                item = candidates.nth(i)
                if await item.is_visible() and await item.is_enabled():
                    return item, label
        except Exception:
            pass
        # Some course sites render navigation as links.
        links = page.get_by_role("link", name=label, exact=True)
        try:
            count = await links.count()
            for i in range(min(count, 5)):
                item = links.nth(i)
                if await item.is_visible() and await item.is_enabled():
                    return item, label
        except Exception:
            pass
    return None, None

async def click_next_after_confirmed_completion(page, logger):
    videos = await page.evaluate("""() => [...document.querySelectorAll('video')].map(v => ({
      ended: v.ended, duration: v.duration, currentTime: v.currentTime
    }))""")
    if not videos or not any(v["ended"] and v["duration"] > 0 for v in videos):
        return "Waiting: no genuinely ended video detected"
    button, label = await find_navigation_button(page)
    if not button:
        return "Video ended; no Next / Finish Topic / Continue control found"
    await button.click()
    logger.info(f"Clicked course navigation after video ended: {label}")
    await page.wait_for_load_state("domcontentloaded", timeout=10000)
    return f"Clicked {label} after video completion"
