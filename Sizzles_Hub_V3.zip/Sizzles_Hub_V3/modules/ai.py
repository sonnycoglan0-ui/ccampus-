import requests

class LocalAI:
    def __init__(self, config):
        self.base = config["ai"]["base_url"].rstrip("/")
        self.model = config["ai"]["model"]

    def ask(self, prompt):
        system = (
            "You are the Sizzles Hub local study helper. Explain concepts clearly, "
            "show reasoning, and help the learner understand. For live graded assessments, "
            "do not provide a direct answer key or complete the assessment; instead explain "
            "the relevant concept and guide the learner to work it out."
        )
        payload = {
            "model": self.model,
            "stream": False,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": prompt}
            ]
        }
        response = requests.post(f"{self.base}/api/chat", json=payload, timeout=120)
        response.raise_for_status()
        return response.json()["message"]["content"]
