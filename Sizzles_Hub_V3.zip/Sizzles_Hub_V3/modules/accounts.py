import keyring
from getpass import getpass

SERVICE = "SizzlesHubV3"

class AccountManager:
    def __init__(self):
        self.accounts = {}

    def add_or_update(self, slot):
        username = input(f"Account {slot} username: ").strip()
        if not username:
            print("Username cannot be empty.")
            return
        password = getpass("Password (stored in Windows credential store): ")
        if not password:
            print("Password cannot be empty.")
            return
        keyring.set_password(SERVICE, f"{slot}:{username}", password)
        self.accounts[str(slot)] = username
        print(f"Account {slot} saved. Password stored by your OS credential manager.")

    def show(self):
        if not self.accounts:
            print("No accounts added in this session yet. Use Manage Accounts to add one.")
        for slot, username in self.accounts.items():
            print(f"Account {slot}: {username}")

    def login_reminder(self):
        print("For safety, sign in manually in the Chromium window.")
