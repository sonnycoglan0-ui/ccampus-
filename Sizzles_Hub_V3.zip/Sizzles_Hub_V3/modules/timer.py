import time
import threading

class WorkTimer:
    def __init__(self):
        self.duration = 25 * 60
        self.remaining = self.duration
        self.running = False
        self._end_at = None
        self._paused_remaining = None
        self.completed = False
        self._lock = threading.Lock()

    def set_minutes(self, minutes):
        seconds = max(1, int(minutes)) * 60
        with self._lock:
            self.duration = seconds
            self.remaining = seconds
            self.running = False
            self._end_at = None
            self.completed = False

    def start(self):
        with self._lock:
            self._end_at = time.monotonic() + self.remaining
            self.running = True
            self.completed = False

    def pause(self):
        with self._lock:
            if self.running:
                self.remaining = max(0, int(self._end_at - time.monotonic()))
                self.running = False
                self._end_at = None

    def resume(self):
        with self._lock:
            if not self.running and self.remaining > 0:
                self._end_at = time.monotonic() + self.remaining
                self.running = True

    def reset(self):
        with self._lock:
            self.remaining = self.duration
            self.running = False
            self._end_at = None
            self.completed = False

    def get_remaining(self):
        with self._lock:
            if self.running:
                self.remaining = max(0, int(self._end_at - time.monotonic()))
                if self.remaining == 0:
                    self.running = False
                    self._end_at = None
                    self.completed = True
            return self.remaining

    def status(self):
        seconds = self.get_remaining()
        return f"{seconds // 60:02d}:{seconds % 60:02d}", self.running, self.completed

def completion_sound():
    try:
        import winsound
        for f, d in [(660, 180), (880, 180), (1100, 350)]:
            winsound.Beep(f, d)
    except Exception:
        print("\a", end="", flush=True)
