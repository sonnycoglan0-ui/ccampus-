import asyncio, time
from playwright.async_api import TimeoutError as PlaywrightTimeoutError

VIDEO_SCRIPT = r"""
() => {
  const videos = [...document.querySelectorAll('video')];
  return videos.map(v => ({
    currentTime: Number.isFinite(v.currentTime) ? v.currentTime : 0,
    duration: Number.isFinite(v.duration) ? v.duration : 0,
    paused: v.paused,
    ended: v.ended,
    readyState: v.readyState
  }));
}
"""

class VideoMonitor:
    def __init__(self, browser, config, logger):
        self.browser = browser
        self.config = config
        self.logger = logger
        self.last_report = "No video detected"

    async def inspect(self):
        page = self.browser.page
        if not page:
            return self.last_report
        phrases = [p.lower() for p in self.config["automation"].get("session_expiry_phrases", [])]
        try:
            body = (await page.locator("body").inner_text(timeout=2500)).lower()
            if any(p in body for p in phrases):
                self.logger.warning("Possible expired session detected")
                return "SESSION EXPIRED"
        except Exception:
            pass
        try:
            videos = await page.evaluate(VIDEO_SCRIPT)
        except Exception:
            return "Unable to inspect current page"
        if not videos:
            self.last_report = "No HTML video detected on current page"
        else:
            v = max(videos, key=lambda x: x["duration"])
            if v["duration"] > 0:
                pct = min(100, int(v["currentTime"] / v["duration"] * 100))
                self.last_report = f"Video {pct}% | {'ended' if v['ended'] else 'playing' if not v['paused'] else 'paused'}"
            else:
                self.last_report = "Video detected | duration not available"
        return self.last_report
