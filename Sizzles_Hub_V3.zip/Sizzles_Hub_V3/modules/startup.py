import os, random, time, sys

LOGO = [
"  ███████╗██╗███████╗███████╗██╗     ███████╗███████╗",
"  ██╔════╝██║╚══███╔╝╚══███╔╝██║     ██╔════╝██╔════╝",
"  ███████╗██║  ███╔╝  ███╔╝ ██║     █████╗  ███████╗",
"  ╚════██║██║ ███╔╝  ███╔╝  ██║     ██╔══╝  ╚════██║",
"  ███████║██║███████╗███████╗███████╗███████╗███████║",
"  ╚══════╝╚═╝╚══════╝╚══════╝╚══════╝╚══════╝╚══════╝"
]
CHARS = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789#$%&@!?/\\<>"

def _sound():
    try:
        import winsound
        # Original short electronic startup motif.
        for freq, duration in [(440, 90), (660, 90), (880, 130), (660, 80), (990, 180)]:
            winsound.Beep(freq, duration)
    except Exception:
        pass

def play_startup():
    os.system("cls" if os.name == "nt" else "clear")
    _sound()
    width = max(len(line) for line in LOGO)
    for frame in range(13):
        os.system("cls" if os.name == "nt" else "clear")
        print("\033[96m")
        for line in LOGO:
            glitch = "".join(random.choice(CHARS) if random.random() < (0.48 if frame < 9 else 0.15) else c for c in line)
            print(glitch[:width].ljust(width))
        print("\033[0m")
        time.sleep(0.055)
    os.system("cls" if os.name == "nt" else "clear")
    print("\033[91m")
    print("\n".join(LOGO))
    print("\033[0m")
    print("                 S I Z Z L E S   H U B   V 3")
    print("                     — by sizzle himself —")
    time.sleep(0.8)
