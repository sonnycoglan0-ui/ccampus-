import os, time, threading
from getpass import getpass
from .settings import load_config, save_config
from .startup import play_startup
from .logger import get_logger
from .timer import WorkTimer, completion_sound
from .accounts import AccountManager
from .ai import LocalAI
from .browser import CampusBrowser
from .video_monitor import VideoMonitor
from .navigation import click_next_after_confirmed_completion

class SizzlesHub:
    def __init__(self):
        self.config = load_config()
        self.logger = get_logger()
        self.timer = WorkTimer()
        self.accounts = AccountManager()
        self.browser = None
        self.browser_status = "Not launched"
        self.last_timer_done = False
        self.ai = LocalAI(self.config)
        self.monitor_thread = None
        self.monitoring = False
        self.last_video_status = "Not started"

    def clear(self):
        os.system("cls" if os.name == "nt" else "clear")

    def dashboard(self):
        timer, running, done = self.timer.status()
        self.clear()
        print("\033[91m" + "=" * 66 + "\033[0m")
        print("  S I Z Z L E S   H U B   V 3       — by sizzle himself —")
        print("\033[91m" + "=" * 66 + "\033[0m")
        print(f"  Chromium : {self.browser_status}")
        print(f"  Video    : {self.last_video_status}")
        print(f"  Local AI : Ollama / {self.config['ai']['model']}")
        print(f"  Timer    : {timer} | {'RUNNING' if running else 'PAUSED/IDLE'}")
        print(f"  Accounts : {len(self.accounts.accounts)}/2 configured this session")
        print("-" * 66)
        print("  [1] Open / connect Community Campus")
        print("  [2] Manage accounts")
        print("  [3] Start video monitoring")
        print("  [4] Check video status")
        print("  [5] Auto-continue settings")
        print("  [6] Local AI study helper")
        print("  [7] Work timer")
        print("  [8] Settings / diagnostics")
        print("  [9] Close Chromium")
        print("  [0] Exit")
        print("-" * 66)

    def run(self):
        play_startup()
        while True:
            self.dashboard()
            choice = input("  sizzles> ").strip()
            if choice == "1": self.open_campus()
            elif choice == "2": self.manage_accounts()
            elif choice == "3": self.start_monitor()
            elif choice == "4": self.check_video()
            elif choice == "5": self.auto_settings()
            elif choice == "6": self.study_ai()
            elif choice == "7": self.timer_menu()
            elif choice == "8": self.settings_menu()
            elif choice == "9": self.close_browser()
            elif choice == "0":
                self.close_browser()
                break

    def pause_screen(self):
        input("\nPress Enter to return to dashboard...")

    def open_campus(self):
        url = self.config.get("campus_url", "").strip()
        if not url:
            url = input("Paste your Community Campus landing-page URL: ").strip()
            if not url.startswith(("https://", "http://")):
                print("That doesn't look like a valid http(s) URL.")
                self.pause_screen(); return
            self.config["campus_url"] = url
            save_config(self.config)
        if not self.browser:
            self.browser = CampusBrowser(self.config, self.logger, self._browser_status)
            self.browser.start()
        if self.browser.error:
            print("Chromium error:", self.browser.error)
        else:
            self.browser.navigate(url)
        self.pause_screen()

    def _browser_status(self, status):
        self.browser_status = status

    def manage_accounts(self):
        print("\nACCOUNT MANAGER — passwords use your OS credential store")
        self.accounts.show()
        slot = input("Choose account slot (1 or 2), or Enter to return: ").strip()
        if slot in ("1", "2"):
            self.accounts.add_or_update(slot)
        self.pause_screen()

    def start_monitor(self):
        if not self.browser or not self.browser.running:
            print("Open Community Campus first.")
        elif self.monitor_thread and self.monitor_thread.is_alive():
            print("Video monitor is already running.")
        else:
            self.monitoring = True
            self.monitor_thread = threading.Thread(target=self._monitor_loop, daemon=True)
            self.monitor_thread.start()
            print("Video monitoring started.")
        self.pause_screen()

    def _monitor_loop(self):
        import asyncio
        while self.monitoring and self.browser and self.browser.loop and self.browser.running:
            try:
                async def inspect():
                    monitor = VideoMonitor(self.browser, self.config, self.logger)
                    return await monitor.inspect()
                future = __import__("asyncio").run_coroutine_threadsafe(inspect(), self.browser.loop)
                self.last_video_status = future.result(timeout=8)
                if self.last_video_status == "SESSION EXPIRED":
                    self.session_expired_alarm()
                    self.monitoring = False
                    break
                auto = self.config["automation"]
                if self.last_video_status.startswith("Video 100%") and (
                    auto.get("auto_continue_after_video") or auto.get("auto_next_after_video")
                ):
                    async def nav():
                        return await click_next_after_confirmed_completion(self.browser.page, self.logger)
                    result = __import__("asyncio").run_coroutine_threadsafe(nav(), self.browser.loop).result(timeout=15)
                    self.logger.info(result)
            except Exception as exc:
                self.logger.warning(f"Monitor issue: {exc}")
            time.sleep(max(2, int(self.config["automation"].get("retry_seconds", 3))))

    def check_video(self):
        print("Current video status:", self.last_video_status)
        self.pause_screen()

    def session_expired_alarm(self):
        print("\n!!! COMMUNITY CAMPUS SESSION MAY HAVE EXPIRED !!!")
        try:
            import winsound
            end = time.monotonic() + 4
            while time.monotonic() < end:
                winsound.Beep(1500, 250)
        except Exception:
            print("\a\a\a\a")
        print("Automation paused. Sign in manually in Chromium, then restart monitoring.")

    def auto_settings(self):
        a = self.config["automation"]
        print("\nAuto-Continue only clicks after a video is genuinely ended.")
        print("Auto-Next only clicks after a video is genuinely ended.")
        print(f"Current Auto-Continue: {a.get('auto_continue_after_video', False)}")
        print(f"Current Auto-Next: {a.get('auto_next_after_video', False)}")
        print("1 Toggle Auto-Continue | 2 Toggle Auto-Next | Enter return")
        choice = input("> ").strip()
        if choice == "1":
            a["auto_continue_after_video"] = not a.get("auto_continue_after_video", False)
        elif choice == "2":
            a["auto_next_after_video"] = not a.get("auto_next_after_video", False)
        save_config(self.config)
        self.pause_screen()

    def study_ai(self):
        print("\nLOCAL AI STUDY HELPER")
        print("Ask it to explain a topic or help you reason through a practice question.")
        prompt = input("\nQuestion: ").strip()
        if prompt:
            try:
                print("\n" + self.ai.ask(prompt))
            except Exception as exc:
                print(f"AI unavailable: {exc}")
                print("Check that Ollama is running and the model has been downloaded.")
        self.pause_screen()

    def timer_menu(self):
        while True:
            self.clear()
            value, running, done = self.timer.status()
            print("WORK TIMER")
            print(f"Time remaining: {value} | {'RUNNING' if running else 'PAUSED/IDLE'}")
            print("[1] Set duration in minutes")
            print("[2] Start")
            print("[3] Pause")
            print("[4] Resume")
            print("[5] Reset")
            print("[Enter] Return")
            choice = input("> ").strip()
            if choice == "1":
                try: self.timer.set_minutes(int(input("Minutes: ")))
                except ValueError: print("Enter a whole number.")
            elif choice == "2": self.timer.start()
            elif choice == "3": self.timer.pause()
            elif choice == "4": self.timer.resume()
            elif choice == "5": self.timer.reset()
            elif not choice: break
            if self.timer.status()[2]:
                completion_sound()
                print("SESSION COMPLETE — NICE WORK!")
                input("Press Enter...")

    def settings_menu(self):
        print("\nDIAGNOSTICS")
        print(f"Campus URL configured: {'Yes' if self.config.get('campus_url') else 'No'}")
        print(f"Browser status: {self.browser_status}")
        print(f"Browser error: {getattr(self.browser, 'error', None) if self.browser else 'Not launched'}")
        print(f"Log file: logs/sizzles_hub.log")
        print("\nEdit config.json to change the URL, AI model, retry interval and browser options.")
        self.pause_screen()

    def close_browser(self):
        self.monitoring = False
        if self.browser:
            try: self.browser.stop()
            except Exception as exc: self.logger.warning(f"Browser close issue: {exc}")
            self.browser = None
            self.browser_status = "Closed"
