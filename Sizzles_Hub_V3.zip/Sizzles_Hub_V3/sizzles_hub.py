from modules.app import SizzlesHub

if __name__ == "__main__":
    SizzlesHub().run()
