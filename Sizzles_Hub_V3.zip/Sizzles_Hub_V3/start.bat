@echo off
title Sizzles Hub V3
python sizzles_hub.py
if errorlevel 1 pause
