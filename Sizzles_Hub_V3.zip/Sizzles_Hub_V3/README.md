# Sizzles Hub V3
**— by sizzle himself —**

Windows CMD Python application for Community Campus session support, local AI study help,
account management, and an independent work timer.

## Install
1. Install Python 3.11 or newer.
2. Extract this folder somewhere writable.
3. Open CMD in this folder and run `install.bat`.
4. Edit `config.json` and set `campus_url` to the actual Community Campus landing-page URL.
5. Run `start.bat`.

## Local AI
Install Ollama separately, start it, then pull the configured model:
`ollama pull qwen2.5:7b`

The AI is a study helper: it can explain concepts and help you reason through practice
questions. It is not designed to complete or submit live graded assessments for you.

## Browser
The first launch opens Chromium with a persistent profile. Sign in manually.
The app does not store your Community Campus password in its config. Saved account
passwords use the operating system credential store through `keyring`.

If Chromium opens `about:blank`, check that `campus_url` is set to a complete `https://...`
URL in `config.json`. The browser page can also be navigated from the dashboard.

## Automation safety
Video monitoring reports playback and completion state. Auto-Continue / Auto-Next are
optional and only attempt ordinary navigation after the video has genuinely ended.
The app does not manipulate clocks, fake watch time, bypass required waiting periods,
or submit assessment answers.

## Project layout
- `sizzles_hub.py` – entry point
- `modules/` – terminal, startup, browser, monitor, AI, timer, accounts, settings
- `config.json` – editable settings
- `logs/` – diagnostic logs
- `browser_profile/` – persistent Chromium profile

## Notes
This is a fresh baseline build. Campus sites differ, so button labels and video frames may
need site-specific tuning after you test it. Keep your course login private.
