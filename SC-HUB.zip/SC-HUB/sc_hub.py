#!/usr/bin/env python3
"""SC HUB - Community Campus command-line automation (runs entirely in Windows CMD)."""
from __future__ import annotations

import sys

if sys.version_info < (3, 11):
    sys.exit("SC HUB needs Python 3.11 or newer.")

import asyncio
import contextlib
import logging
import time
from logging.handlers import RotatingFileHandler
from typing import Any

try:
    from modules import terminal as ui
    from modules.browser import BrowserError, BrowserManager, CampusUnavailable
    from modules.monitor import AppState, VideoMonitor
    from modules.navigation import Navigator
    from modules.settings import APP_VERSION, FIELD_META, LOG_DIR, LOG_FILE, Settings
except ImportError as exc:
    sys.exit(
        f"Missing dependency: {exc}\n"
        "Run:  pip install -r requirements.txt\n"
        "Then: python -m playwright install chromium"
    )

log = logging.getLogger("sc_hub")


def setup_logging(settings: Settings) -> None:
    for handler in list(log.handlers):
        log.removeHandler(handler)
        handler.close()
    log.propagate = False
    log.setLevel(getattr(logging, settings.log_level, logging.INFO))
    if settings.logging_enabled:
        LOG_DIR.mkdir(parents=True, exist_ok=True)
        handler = RotatingFileHandler(LOG_FILE, maxBytes=1_000_000, backupCount=3, encoding="utf-8")
        handler.setFormatter(logging.Formatter("%(asctime)s [%(levelname)s] %(name)s: %(message)s"))
        log.addHandler(handler)
    else:
        log.addHandler(logging.NullHandler())


class App:
    def __init__(self) -> None:
        self.settings = Settings.load()
        setup_logging(self.settings)
        self.state = AppState(auto_continue=self.settings.auto_continue_default)
        self.browser = BrowserManager(self.settings, self.state)
        self.monitor = VideoMonitor()
        self.nav = Navigator(self.settings)
        self._task: asyncio.Task | None = None
        self._bg: set[asyncio.Task] = set()
        self._alerted: set[str] = set()
        self._completed_key: str | None = None
        self._last_error = ("", 0.0)
        self.handlers = {
            "1": self.connect,
            "2": self.start_monitoring,
            "3": self.enable_auto,
            "4": self.disable_auto,
            "5": self.manual_continue,
            "6": self.view_info,
            "7": self.configuration,
            "8": self.view_logs,
            "9": self.stop_automation,
        }

    # ------------------------------------------------------------------ helpers
    def note(self, message: str, level: int = logging.INFO) -> None:
        """Write to the log file and the on-screen activity feed."""
        log.log(level, message)
        name = "error" if level >= logging.ERROR else "warning" if level >= logging.WARNING else "info"
        self.state.event(message, name)

    def attention(self, key: str, message: str) -> None:
        """Warn once per situation and sound the alarm (if enabled)."""
        if key in self._alerted:
            return
        if len(self._alerted) > 200:
            self._alerted.clear()
        self._alerted.add(key)
        self.note(message, logging.WARNING)
        if self.settings.alarm_on_attention:
            task = asyncio.create_task(asyncio.to_thread(ui.alarm, 4.0))
            self._bg.add(task)
            task.add_done_callback(self._bg.discard)

    async def refresh_page_state(self) -> Any | None:
        """Update connection/page status; return the usable Community Campus page or None."""
        st = self.state
        if not self.browser.alive:
            st.connection = "DISCONNECTED"
            st.page_status = "Browser not connected - use option [1]"
            return None
        if self.browser.has_crashed():
            try:
                await self.browser.recover_crashed()
                self.note("Recovered from a browser tab crash.", logging.WARNING)
            except Exception as exc:
                self.note(f"Crash recovery failed: {exc}", logging.ERROR)
        page = await self.browser.active_page()
        if page is None:
            if self.browser.site_unavailable():
                st.connection = "UNAVAILABLE"
                st.page_status = "Community Campus is unavailable (the browser could not load it)"
            else:
                st.connection = "NO PAGE"
                st.page_status = "No Community Campus page open - use option [1] or open it in the browser"
            return None
        if await self.browser.login_required(page):
            st.connection = "LOGIN REQUIRED"
            st.page_status = "Login required - sign in in the browser window"
            return None
        st.connection = "CONNECTED"
        self._alerted.discard("login")
        return page

    # ---------------------------------------------------------- monitoring loop
    async def tick(self) -> None:
        st = self.state
        page = await self.refresh_page_state()
        if page is None:
            st.info = None
            self.monitor.reset()
            self.nav.note_key(None)
            if st.connection == "LOGIN REQUIRED":
                self.attention("login", "Login required - sign in in the browser window.")
            return

        video = await self.monitor.read(page)
        if video is None:
            st.info = None
            st.page_status = "No video detected on this page (use Manual Continue for non-video pages)"
            self.nav.note_key(None)
            return

        st.info = video
        st.page_status = "Video detected" + (f" ({self.monitor.skipped_frames} frame(s) unreadable)"
                                             if self.monitor.skipped_frames else "")
        self.nav.note_key(video.key)
        if video.is_new:
            self.note(f"Video detected: {video.title} ({ui.fmt_clock(video.duration)})")

        if self.settings.auto_play:
            result = await self.monitor.ensure_playing(video)
            if result:
                self.note(f"Auto-play: {result}")

        if video.confirmed_finished and self._completed_key != video.key:
            self._completed_key = video.key
            st.completed += 1
            self.note(f"Video completed: {video.title}")

        if (st.auto_continue and video.confirmed_finished
                and video.finished_for >= self.settings.navigation_delay
                and not self.nav.already_attempted(video.key)):
            await self.auto_advance(page, video)

    async def auto_advance(self, page: Any, video: Any) -> None:
        result = await self.nav.continue_now(page, self.monitor.read, auto=True,
                                             delay=self.settings.navigation_delay)
        if result.ok:
            self.state.advanced += 1
            self.note(f"Auto-Continue: {result.message}")
        elif result.code == "unconfirmed":
            self.attention(f"noeffect:{video.key}", f"Auto-Continue: {result.message} Needs you.")
        elif result.code == "click_failed":
            self.attention(f"clickfail:{video.key}", f"Auto-Continue: {result.message}")
        elif result.code == "no_button" and video.finished_for > 20:
            self.attention(f"nobutton:{video.key}",
                           "Video finished but no Next / Continue / Finish Topic button was found. Needs you.")

    async def _loop(self) -> None:
        log.info("Monitoring started")
        try:
            while True:
                try:
                    await self.tick()
                except asyncio.CancelledError:
                    raise
                except Exception as exc:
                    self.state.errors += 1
                    self.state.page_status = f"Recoverable error: {exc.__class__.__name__}"
                    text, when = self._last_error
                    if str(exc) != text or time.monotonic() - when > 30:
                        self._last_error = (str(exc), time.monotonic())
                        log.exception("Monitoring error (continuing)")
                        self.state.event(f"Error: {exc.__class__.__name__}: {str(exc)[:80]}", "error")
                await asyncio.sleep(max(0.1, self.settings.refresh_interval))
        finally:
            log.info("Monitoring stopped")

    def _monitor_running(self) -> bool:
        return self._task is not None and not self._task.done()

    async def _stop_monitoring(self) -> None:
        task, self._task = self._task, None
        if task is not None and not task.done():
            task.cancel()
            with contextlib.suppress(asyncio.CancelledError, Exception):
                await task
        self.state.monitoring = False

    # ------------------------------------------------------------ menu actions
    async def connect(self) -> None:
        ui.section("CONNECT TO COMMUNITY CAMPUS")
        if self.browser.alive:
            ui.info("Browser is already running.")
        else:
            ui.info(f"Launching {self.settings.browser} with a persistent profile...")
            try:
                await self.browser.start()
            except BrowserError as exc:
                self.state.connection = "DISCONNECTED"
                self.note(f"Browser connection failed: {exc}", logging.ERROR)
                ui.err(str(exc))
                return
        try:
            page = await self.browser.open_campus()
        except CampusUnavailable as exc:
            self.state.connection = "UNAVAILABLE"
            self.note(f"Community Campus unavailable: {exc}", logging.ERROR)
            ui.err(f"Community Campus is unavailable: {exc}")
            ui.info("The browser stays open. Use option [1] again when the site is back.")
            return
        except BrowserError as exc:
            ui.err(str(exc))
            return
        if await self.browser.login_required(page):
            self.state.connection = "LOGIN REQUIRED"
            self.note("Connected - login required.")
            ui.warn("Log in manually in the browser window. Your password is never read or stored.")
            ui.info("Then open a lesson and choose option [2].")
        else:
            self.state.connection = "CONNECTED"
            self.note("Connected to Community Campus.")
            ui.ok("Connected. Open a lesson in the browser, then choose option [2].")

    async def start_monitoring(self) -> None:
        if not self.browser.alive:
            ui.err("Browser not connected. Use option [1] first.")
            await ui.pause()
            return
        if not self._monitor_running():
            self._task = asyncio.create_task(self._loop())
            self.state.monitoring = True
            self.state.event("Monitoring started")
        ui.clear()
        while True:
            ui.draw(ui.render_live(self.state, self.settings))
            deadline = time.monotonic() + max(0.25, self.settings.refresh_interval)
            while time.monotonic() < deadline:
                if ui.key_pressed():
                    return
                await asyncio.sleep(0.05)

    async def enable_auto(self) -> None:
        self.state.auto_continue = True
        self.note("Auto-Continue enabled.")
        ui.ok(f"Auto-Continue ENABLED (delay {self.settings.navigation_delay:g}s after a video finishes).")
        if not self.state.monitoring:
            ui.warn("It only acts while monitoring is running - start it with option [2].")

    async def disable_auto(self) -> None:
        self.state.auto_continue = False
        self.note("Auto-Continue disabled.")
        ui.ok("Auto-Continue DISABLED.")

    async def manual_continue(self) -> None:
        ui.section("MANUAL CONTINUE")
        page = await self.refresh_page_state()
        if page is None:
            ui.err(self.state.page_status)
            return
        result = await self.nav.continue_now(page, self.monitor.read, auto=False)
        if result.ok:
            self.state.advanced += 1
            self.note(f"Manual Continue: {result.message}")
            ui.ok(result.message)
        elif result.clicked:
            self.note(f"Manual Continue: {result.message}", logging.WARNING)
            ui.warn(result.message)
        else:
            ui.warn(result.message)

    async def view_info(self) -> None:
        ui.section("CURRENT VIDEO INFORMATION")
        page = await self.refresh_page_state()
        if page is None:
            ui.err(self.state.page_status)
            return
        video = await self.monitor.read(page, track=False)
        ui.say(f"Page: {page.url}")
        for line in ui.video_block(video, self.state, self.settings):
            ui.say(line)
        if video is None:
            ui.warn("No video detected on the current page.")
        else:
            where = "main page" if video.frame_url == page.url else f"embedded frame ({ui.video_url_host(video.frame_url)})"
            ui.say(f"Source: {where}")
        if self.monitor.skipped_frames:
            ui.warn(f"{self.monitor.skipped_frames} embedded frame(s) could not be read.")
        control = await self.nav.find_control(page)
        ui.say("Navigation control: " + (f"found - '{control.label}'" if control else "none available"))

    async def configuration(self) -> None:
        while True:
            ui.clear()
            ui.section("CONFIGURATION")
            ui.render_config(self.settings)
            choice = (await ui.read_line("Select a setting to change [0 = back]: ")).strip()
            if choice in ("", "0"):
                return
            if not choice.isdigit() or not 1 <= int(choice) <= len(FIELD_META):
                ui.warn("Invalid choice.")
                await ui.pause()
                continue
            await self._edit_setting(*FIELD_META[int(choice) - 1])

    async def _edit_setting(self, key: str, label: str, kind: str, extra: Any) -> None:
        current = getattr(self.settings, key)
        if kind == "bool":
            raw: Any = not current
        else:
            if kind == "float":
                hint = f"{extra[0]:g}-{extra[1]:g}"
            elif kind == "choice":
                hint = ", ".join(f"{i}={o}" for i, o in enumerate(extra, 1))
            else:
                hint = "blank clears"
            raw = await ui.read_line(f"New value for '{label}' ({hint}): ")
            if kind != "text" and not raw.strip():
                ui.info("Unchanged.")
                await ui.pause()
                return
        try:
            value = self.settings.set_value(key, raw)
            self.settings.save()
        except ValueError as exc:
            ui.err(f"Invalid value: {exc}")
            await ui.pause()
            return
        except OSError as exc:
            ui.err(f"Changed for this session, but config.json could not be saved: {exc}")
            await ui.pause()
            return
        if key in ("logging_enabled", "log_level"):
            setup_logging(self.settings)
        log.info("Setting changed: %s = %r", key, value)
        ui.ok(f"{label} = {value if kind != 'bool' else ('ON' if value else 'OFF')}")
        if key == "browser" and self.browser.alive:
            ui.info("Applies the next time the browser starts (close its window, then use option [1]).")
        if key == "auto_continue_default":
            ui.info("Applies at startup. Use options [3] / [4] to change it right now.")
        await ui.pause()

    async def view_logs(self) -> None:
        ui.section("ACTIVITY LOGS")
        if not LOG_FILE.exists():
            ui.warn("No log entries yet." + ("" if self.settings.logging_enabled
                                              else " Logging is turned off in Configuration."))
            return
        lines = LOG_FILE.read_text(encoding="utf-8", errors="replace").splitlines()[-40:]
        ui.print_log_lines(lines)
        ui.say()
        ui.info(f"Full log file: {LOG_FILE}")

    async def stop_automation(self) -> None:
        was_running = self._monitor_running()
        await self._stop_monitoring()
        self.state.auto_continue = False
        self.state.info = None
        self.monitor.reset()
        self.note("Automation stopped (monitoring and Auto-Continue off).")
        ui.ok("Automation stopped." if was_running else "Automation was not running. Auto-Continue is off.")
        ui.info("The browser stays open. Use option [2] to monitor again.")

    # --------------------------------------------------------------- main loop
    async def run(self) -> None:
        log.info("Application startup (SC HUB v%s)", APP_VERSION)
        try:
            if self.settings.load_warnings:
                for warning in self.settings.load_warnings:
                    log.warning(warning)
                    ui.warn(warning)
                await ui.pause("Press Enter to continue...")
            while True:
                ui.clear()
                ui.banner(self.state, self.settings)
                ui.menu()
                choice = (await ui.read_line("Select an option [0-9]: ")).strip()
                if choice == "0":
                    break
                handler = self.handlers.get(choice)
                if handler is None:
                    ui.warn("Invalid option - type a number from 0 to 9.")
                    await ui.pause()
                    continue
                try:
                    await handler()
                except (asyncio.CancelledError, ui.ExitRequested):
                    raise
                except Exception as exc:
                    self.state.errors += 1
                    log.exception("Menu action %s failed", choice)
                    ui.err(f"Something went wrong: {exc.__class__.__name__}: {str(exc)[:120]}")
                    ui.info("The application is still running. Details are in the activity log.")
                if choice not in ("2", "7"):
                    await ui.pause()
        except ui.ExitRequested:
            pass
        finally:
            await self.shutdown()

    async def shutdown(self) -> None:
        await self._stop_monitoring()
        await self.browser.close()
        log.info("Application shutdown")
        logging.shutdown()


def main() -> int:
    ui.init()
    LOG_DIR.mkdir(parents=True, exist_ok=True)
    app = App()
    with contextlib.suppress(KeyboardInterrupt):
        asyncio.run(app.run())
    ui.goodbye()
    return 0


if __name__ == "__main__":
    sys.exit(main())
