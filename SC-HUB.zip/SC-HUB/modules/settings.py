"""Paths, defaults, validation and config.json persistence for SC HUB."""
from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

APP_NAME = "SC HUB"
APP_VERSION = "1.0.0"

BASE_DIR = Path(__file__).resolve().parent.parent
CONFIG_PATH = BASE_DIR / "config.json"
LOG_DIR = BASE_DIR / "logs"
LOG_FILE = LOG_DIR / "sc_hub.log"
PROFILE_DIR = BASE_DIR / "browser_profile"

BROWSER_CHOICES = ("chromium", "chrome", "msedge")
LOG_LEVELS = ("DEBUG", "INFO", "WARNING", "ERROR")

# (key, label, kind, extra) - drives the Configuration menu.
FIELD_META: list[tuple[str, str, str, Any]] = [
    ("auto_continue_default", "Auto-Continue default state", "bool", None),
    ("navigation_delay", "Navigation delay (seconds)", "float", (0.0, 60.0)),
    ("refresh_interval", "Monitoring refresh interval (seconds)", "float", (0.25, 10.0)),
    ("browser", "Browser", "choice", BROWSER_CHOICES),
    ("auto_play", "Auto-play paused videos", "bool", None),
    ("alarm_on_attention", "Alarm when attention is needed", "bool", None),
    ("custom_next_selector", "Custom Next-button CSS selector", "text", None),
    ("logging_enabled", "Write activity log", "bool", None),
    ("log_level", "Log level", "choice", LOG_LEVELS),
]
_META = {m[0]: m for m in FIELD_META}


def _to_bool(value: Any) -> bool:
    if isinstance(value, bool):
        return value
    text = str(value).strip().lower()
    if text in ("1", "true", "yes", "y", "on", "enable", "enabled"):
        return True
    if text in ("0", "false", "no", "n", "off", "disable", "disabled"):
        return False
    raise ValueError("enter on/off (or yes/no)")


def _to_float(value: Any, low: float, high: float) -> float:
    try:
        number = float(str(value).strip().replace(",", "."))
    except ValueError:
        raise ValueError("enter a number") from None
    if not low <= number <= high:
        raise ValueError(f"must be between {low:g} and {high:g}")
    return number


def _to_choice(value: Any, options: tuple[str, ...]) -> str:
    text = str(value).strip().lower()
    for option in options:
        if text == option.lower():
            return option
    if text.isdigit() and 1 <= int(text) <= len(options):
        return options[int(text) - 1]
    raise ValueError("choose one of: " + ", ".join(options))


def _to_url(value: Any) -> str:
    text = str(value).strip().rstrip("/")
    parsed = urlparse(text)
    if parsed.scheme not in ("http", "https") or not parsed.hostname:
        raise ValueError("must be a full URL starting with http:// or https://")
    return text


@dataclass
class Settings:
    campus_url: str = "https://communitycampus.online"
    auto_continue_default: bool = False
    navigation_delay: float = 3.0
    refresh_interval: float = 1.0
    browser: str = "chromium"
    auto_play: bool = True
    alarm_on_attention: bool = True
    custom_next_selector: str = ""
    logging_enabled: bool = True
    log_level: str = "INFO"
    load_warnings: list[str] = field(default_factory=list, repr=False, compare=False)

    # ----- validation -----
    @staticmethod
    def coerce(key: str, value: Any) -> Any:
        if key == "campus_url":
            return _to_url(value)
        _, _, kind, extra = _META[key]
        if kind == "bool":
            return _to_bool(value)
        if kind == "float":
            return _to_float(value, *extra)
        if kind == "choice":
            return _to_choice(value, extra)
        return str(value).strip()

    def set_value(self, key: str, value: Any) -> Any:
        coerced = self.coerce(key, value)
        setattr(self, key, coerced)
        return coerced

    @property
    def campus_host(self) -> str:
        host = (urlparse(self.campus_url).hostname or "").lower()
        return host[4:] if host.startswith("www.") else host

    # ----- persistence -----
    def to_dict(self) -> dict[str, Any]:
        data: dict[str, Any] = {"campus_url": self.campus_url}
        for key, *_ in FIELD_META:
            data[key] = getattr(self, key)
        return data

    def save(self, path: Path = CONFIG_PATH) -> None:
        tmp = path.with_suffix(".tmp")
        tmp.write_text(json.dumps(self.to_dict(), indent=2) + "\n", encoding="utf-8")
        os.replace(tmp, path)

    @classmethod
    def load(cls, path: Path = CONFIG_PATH) -> "Settings":
        settings = cls()
        if not path.exists():
            try:
                settings.save(path)
            except OSError as exc:
                settings.load_warnings.append(f"Could not create config.json: {exc}")
            return settings
        try:
            raw = json.loads(path.read_text(encoding="utf-8"))
        except (OSError, ValueError) as exc:
            settings.load_warnings.append(f"config.json is unreadable ({exc}). Defaults are in use.")
            return settings
        if not isinstance(raw, dict):
            settings.load_warnings.append("config.json must contain a JSON object. Defaults are in use.")
            return settings
        for key, value in raw.items():
            if key != "campus_url" and key not in _META:
                continue
            try:
                setattr(settings, key, cls.coerce(key, value))
            except ValueError as exc:
                settings.load_warnings.append(f"config.json: invalid '{key}' ({exc}); default kept.")
        return settings
