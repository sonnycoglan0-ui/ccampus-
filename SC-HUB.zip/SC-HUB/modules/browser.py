"""Playwright browser management: persistent profile, page discovery, crash recovery."""
from __future__ import annotations

import contextlib
import logging
import re
from typing import Any
from urllib.parse import urlparse

from playwright.async_api import Error as PlaywrightError
from playwright.async_api import async_playwright

from .monitor import AppState
from .settings import PROFILE_DIR, Settings

log = logging.getLogger("sc_hub.browser")

_LOGIN_PATH = re.compile(r"/(log-?in|sign-?in|sign_in|auth(enticate)?)(/|$)", re.I)
_BLANK_URLS = ("about:blank", "chrome://newtab/", "chrome://new-tab-page/", "edge://newtab/")


class BrowserError(Exception):
    """The browser could not be started or is not usable."""


class CampusUnavailable(Exception):
    """Community Campus could not be reached."""


def _short(exc: BaseException) -> str:
    text = str(exc).strip().splitlines()
    return (text[0] if text else exc.__class__.__name__)[:160]


class BrowserManager:
    def __init__(self, settings: Settings, state: AppState) -> None:
        self.settings = settings
        self.state = state
        self._pw: Any = None
        self._ctx: Any = None
        self._ctx_closed = True
        self._closing = False
        self._crashed: list[Any] = []
        self.last_url = ""

    # ---------------------------------------------------------------- lifecycle
    @property
    def alive(self) -> bool:
        return self._ctx is not None and not self._ctx_closed

    async def start(self) -> None:
        """Launch the browser with the persistent profile (no-op if already running)."""
        if self.alive:
            return
        await self._dispose()
        PROFILE_DIR.mkdir(parents=True, exist_ok=True)
        kwargs: dict[str, Any] = {
            "user_data_dir": str(PROFILE_DIR),
            "headless": False,
            "no_viewport": True,
            "args": ["--start-maximized"],
        }
        if self.settings.browser in ("chrome", "msedge"):
            kwargs["channel"] = self.settings.browser
        try:
            self._pw = await async_playwright().start()
            self._ctx = await self._pw.chromium.launch_persistent_context(**kwargs)
        except Exception as exc:
            log.error("Browser launch failed: %s", _short(exc))
            await self._dispose()
            raise BrowserError(self._explain(exc)) from exc
        self._ctx_closed = False
        self._closing = False
        self._crashed.clear()
        self._ctx.on("close", self._on_context_close)
        self._ctx.on("page", self._watch_page)
        for page in self._ctx.pages:
            self._watch_page(page)
        self.state.browser = "RUNNING"
        log.info("Browser connected (%s)", self.settings.browser)

    async def close(self) -> None:
        await self._dispose()
        self.state.browser = "CLOSED"

    async def _dispose(self) -> None:
        self._closing = True
        ctx, pw = self._ctx, self._pw
        self._ctx = None
        self._pw = None
        self._ctx_closed = True
        if ctx is not None:
            with contextlib.suppress(Exception):
                await ctx.close()
        if pw is not None:
            with contextlib.suppress(Exception):
                await pw.stop()

    def _explain(self, exc: BaseException) -> str:
        text = str(exc)
        if "Executable doesn't exist" in text or "playwright install" in text:
            return "Chromium is not installed. Run:  python -m playwright install chromium"
        if self.settings.browser != "chromium" and ("distribution" in text or "is not found" in text):
            return (f"'{self.settings.browser}' is not installed on this PC. "
                    "Pick another browser in Configuration (option 7).")
        if "closed" in text.lower() or "ProcessSingleton" in text or "in use" in text.lower():
            return ("The browser exited immediately. Close any other SC HUB window or browser using "
                    "this profile and try again.")
        return f"Could not start the browser: {_short(exc)}"

    # ------------------------------------------------------------------- events
    def _on_context_close(self, *_: Any) -> None:
        self._ctx_closed = True
        self.state.browser = "CLOSED"
        if not self._closing:
            log.warning("Browser was closed or lost")
            self.state.event("Browser closed - use option [1] to reconnect", "warning")

    def _watch_page(self, page: Any) -> None:
        page.on("crash", lambda *_: self._on_page_crash(page))

    def _on_page_crash(self, page: Any) -> None:
        log.error("Page crashed: %s", page.url)
        self._crashed.append(page)
        self.state.browser = "CRASHED"
        self.state.event("A browser tab crashed - recovering", "error")

    def has_crashed(self) -> bool:
        return any(not p.is_closed() for p in self._crashed)

    async def recover_crashed(self) -> None:
        """Replace crashed tabs with a fresh tab on the last known page."""
        for old in list(self._crashed):
            self._crashed.remove(old)
            target = self.last_url or self.settings.campus_url
            new = await self._ctx.new_page()
            with contextlib.suppress(Exception):
                await new.goto(target, wait_until="domcontentloaded", timeout=30000)
            with contextlib.suppress(Exception):
                await old.close()
            log.info("Recovered crashed tab -> %s", target)
        self.state.browser = "RUNNING"

    # -------------------------------------------------------------------- pages
    def is_campus_url(self, url: str) -> bool:
        host = (urlparse(url).hostname or "").lower()
        base = self.settings.campus_host
        return bool(base) and (host == base or host == "www." + base or host.endswith("." + base))

    async def active_page(self) -> Any | None:
        """The foreground Community Campus tab, or None."""
        if not self.alive:
            return None
        pages = [p for p in self._ctx.pages
                 if not p.is_closed() and p not in self._crashed and self.is_campus_url(p.url)]
        if not pages:
            return None
        chosen = pages[-1]
        if len(pages) > 1:
            for page in reversed(pages):
                try:
                    if await page.evaluate("document.visibilityState") == "visible":
                        chosen = page
                        break
                except Exception:
                    continue
        self.last_url = chosen.url
        return chosen

    def site_unavailable(self) -> bool:
        if not self.alive:
            return False
        return any(p.url.startswith("chrome-error://") for p in self._ctx.pages if not p.is_closed())

    async def open_campus(self) -> Any:
        """Focus an open Community Campus tab, or open one. Raises CampusUnavailable."""
        if not self.alive:
            raise BrowserError("The browser is not running.")
        page = await self.active_page()
        if page is not None:
            with contextlib.suppress(Exception):
                await page.bring_to_front()
            return page
        page = next((p for p in self._ctx.pages
                     if not p.is_closed() and (p.url in _BLANK_URLS or p.url.startswith("chrome-error://"))), None)
        if page is None:
            page = await self._ctx.new_page()
        try:
            response = await page.goto(self.settings.campus_url, wait_until="domcontentloaded", timeout=30000)
        except PlaywrightError as exc:
            log.error("Community Campus unavailable: %s", _short(exc))
            raise CampusUnavailable(_short(exc)) from exc
        if response is not None and response.status >= 500:
            log.error("Community Campus returned HTTP %s", response.status)
            raise CampusUnavailable(f"HTTP {response.status}")
        self.last_url = page.url
        return page

    async def login_required(self, page: Any) -> bool:
        """True if the page looks like a login screen (URL pattern or a visible password field)."""
        if _LOGIN_PATH.search(urlparse(page.url).path or ""):
            return True
        try:
            return await page.locator("input[type='password']:visible").count() > 0
        except Exception:
            return False
