"""Command Prompt user interface: banner, menus, live view, async input, alarm."""
from __future__ import annotations

import asyncio
import os
import shutil
import sys
import time
from datetime import datetime
from typing import Any
from urllib.parse import urlparse

import colorama
from colorama import Fore, Style

from .monitor import AppState, VideoInfo
from .settings import APP_NAME, APP_VERSION, FIELD_META, Settings

if os.name == "nt":
    import msvcrt
else:
    import select

RESET = Style.RESET_ALL
BOLD = Style.BRIGHT
CYAN, GREEN, YELLOW, RED, MAGENTA, DIM = Fore.CYAN, Fore.GREEN, Fore.YELLOW, Fore.RED, Fore.MAGENTA, Style.DIM

BANNER = r"""
███████╗ ██████╗    ██╗  ██╗██╗   ██╗██████╗
██╔════╝██╔════╝    ██║  ██║██║   ██║██╔══██╗
███████╗██║         ███████║██║   ██║██████╔╝
╚════██║██║         ██╔══██║██║   ██║██╔══██╗
███████║╚██████╗    ██║  ██║╚██████╔╝██████╔╝
╚══════╝ ╚═════╝    ╚═╝  ╚═╝ ╚═════╝ ╚═════╝
""".strip("\n")

MENU = [
    ("1", "Connect to Community Campus"),
    ("2", "Start Video Monitoring"),
    ("3", "Enable Auto-Continue"),
    ("4", "Disable Auto-Continue"),
    ("5", "Manual Continue"),
    ("6", "View Current Video Information"),
    ("7", "Configuration"),
    ("8", "View Activity Logs"),
    ("9", "Stop Automation"),
    ("0", "Exit"),
]


class ExitRequested(Exception):
    """Ctrl+C or end-of-input while waiting for the user."""


# ------------------------------------------------------------------ basics
def init() -> None:
    try:
        colorama.just_fix_windows_console()
    except AttributeError:  # very old colorama
        colorama.init()
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass
    if os.name == "nt":
        os.system(f"title {APP_NAME} - Community Campus Automation")


def clear() -> None:
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()


def draw(lines: list[str]) -> None:
    """Redraw a frame in place (no flicker): home cursor, clear each line's tail, clear below."""
    sys.stdout.write("\033[H" + "".join(f"{line}\033[K\n" for line in lines) + "\033[J")
    sys.stdout.flush()


def say(text: str = "") -> None:
    print(text)


def info(text: str) -> None:
    print(f"{CYAN}[{APP_NAME}]{RESET} {text}")


def ok(text: str) -> None:
    print(f"{GREEN}[{APP_NAME}] {text}{RESET}")


def warn(text: str) -> None:
    print(f"{YELLOW}[{APP_NAME}] {text}{RESET}")


def err(text: str) -> None:
    print(f"{RED}[{APP_NAME}] {text}{RESET}")


def section(title: str) -> None:
    print(f"\n{BOLD}{CYAN}[{APP_NAME}] {title}{RESET}\n")


def goodbye() -> None:
    print(f"\n{CYAN}[{APP_NAME}] Goodbye.{RESET}")


def fmt_clock(seconds: float | None) -> str:
    if seconds is None or seconds < 0:
        return "--:--"
    total = int(seconds)
    hours, rest = divmod(total, 3600)
    minutes, secs = divmod(rest, 60)
    return f"{hours}:{minutes:02d}:{secs:02d}" if hours else f"{minutes:02d}:{secs:02d}"


def _width() -> int:
    return max(40, shutil.get_terminal_size((100, 30)).columns - 1)


def _clip(text: str, room: int | None = None) -> str:
    room = room or _width()
    return text if len(text) <= room else text[: room - 1] + "\u2026"


def _status_colour(value: str) -> str:
    good = {"CONNECTED", "RUNNING", "ACTIVE", "ENABLED", "PLAYING"}
    bad = {"DISCONNECTED", "CLOSED", "CRASHED", "UNAVAILABLE"}
    colour = GREEN if value in good else RED if value in bad else YELLOW
    return f"{colour}{value}{RESET}"


# ------------------------------------------------------------------- screens
def banner(state: AppState, settings: Settings) -> None:
    print(f"{CYAN}{BANNER}{RESET}")
    print(f"\n{BOLD}{MAGENTA}         COMMUNITY CAMPUS AUTOMATION{RESET}\n")
    rows = [
        ("Version", f"{APP_VERSION}"),
        ("Connection", _status_colour(state.connection)),
        ("Browser", _status_colour(state.browser) + f" {DIM}({settings.browser}){RESET}"),
        ("Monitoring", _status_colour("ACTIVE" if state.monitoring else "STOPPED")),
        ("Auto-Continue", _status_colour("ENABLED" if state.auto_continue else "DISABLED")),
        ("Date/Time", datetime.now().strftime("%Y-%m-%d %H:%M:%S")),
    ]
    for label, value in rows:
        print(f"  {label:<14}: {value}")
    print()


def menu() -> None:
    for key, text in MENU:
        print(f"  {CYAN}[{key}]{RESET} {text}")
    print()


def video_block(video: VideoInfo | None, state: AppState, settings: Settings) -> list[str]:
    auto = "ENABLED" if state.auto_continue else "DISABLED"
    if video is None:
        return [
            f"Video: {DIM}-{RESET}",
            f"Progress: --:-- / --:--",
            f"Completion: -",
            f"Status: {YELLOW}NO VIDEO{RESET}",
            f"Auto-Continue: {_status_colour(auto)}",
        ]
    filled = video.percent * 24 // 100
    bar = f"{GREEN}{'█' * filled}{DIM}{'░' * (24 - filled)}{RESET}"
    lines = [
        f"Video: {BOLD}{_clip(video.title, _width() - 8)}{RESET}",
        f"Progress: {fmt_clock(video.current)} / {fmt_clock(video.duration) if video.duration else '--:--'}  {bar}",
        f"Completion: {video.percent}%",
        f"Status: {_status_colour(video.status)}",
        f"Auto-Continue: {_status_colour(auto)}",
    ]
    if state.auto_continue and video.finished:
        left = max(0, settings.navigation_delay - video.finished_for)
        lines.append(f"{DIM}Continuing in {left:.0f}s...{RESET}")
    return lines


def render_live(state: AppState, settings: Settings) -> list[str]:
    lines = [f"{BOLD}{CYAN}[{APP_NAME}] VIDEO MONITORING{RESET}", ""]
    lines += video_block(state.info, state, settings)
    lines += [
        "",
        f"Page: {_clip(state.page_status, _width() - 6)}",
        f"Connection: {_status_colour(state.connection)}   Completed: {state.completed}   "
        f"Advanced: {state.advanced}   Errors: {state.errors}",
        "",
        f"{DIM}Recent activity:{RESET}",
    ]
    if state.events:
        for when, level, message in list(state.events):
            colour = RED if level == "error" else YELLOW if level == "warning" else RESET
            lines.append(f"  {DIM}{when:%H:%M:%S}{RESET} {colour}{_clip(message, _width() - 12)}{RESET}")
    else:
        lines.append(f"  {DIM}(nothing yet){RESET}")
    lines += ["", f"{DIM}Press any key to return to the menu - monitoring keeps running.{RESET}"]
    return lines


def render_config(settings: Settings) -> None:
    for number, (key, label, kind, extra) in enumerate(FIELD_META, start=1):
        value = getattr(settings, key)
        if kind == "bool":
            shown = f"{GREEN}ON{RESET}" if value else f"{YELLOW}OFF{RESET}"
        elif kind == "text":
            shown = value or f"{DIM}(none){RESET}"
        else:
            shown = str(value)
        hint = f"  {DIM}({' / '.join(extra)}){RESET}" if kind == "choice" else ""
        print(f"  {CYAN}[{number}]{RESET} {label:<40} {shown}{hint}")
    print(f"  {CYAN}[0]{RESET} Back\n")
    print(f"{DIM}Saved automatically to config.json.{RESET}\n")


def print_log_lines(lines: list[str]) -> None:
    for line in lines:
        colour = RED if "[ERROR]" in line or "[CRITICAL]" in line else YELLOW if "[WARNING]" in line else RESET
        print(f"{colour}{_clip(line)}{RESET}")


def video_url_host(url: str) -> str:
    return urlparse(url).netloc or url


# --------------------------------------------------------------------- input
def key_pressed() -> bool:
    """True if the user pressed something (and consume it)."""
    if os.name == "nt":
        if msvcrt.kbhit():
            while msvcrt.kbhit():
                msvcrt.getwch()
            return True
        return False
    if select.select([sys.stdin], [], [], 0)[0]:
        sys.stdin.readline()
        return True
    return False


async def read_line(prompt: str = "") -> str:
    """Non-blocking line input so background monitoring keeps running while the menu waits."""
    sys.stdout.write(prompt)
    sys.stdout.flush()
    if os.name == "nt":
        buffer: list[str] = []
        while True:
            if not msvcrt.kbhit():
                await asyncio.sleep(0.02)
                continue
            char = msvcrt.getwch()
            if char in ("\r", "\n"):
                sys.stdout.write("\n")
                return "".join(buffer)
            if char == "\x03":
                raise ExitRequested
            if char in ("\x00", "\xe0"):  # arrow / function key: swallow the second code
                msvcrt.getwch()
            elif char == "\x08":
                if buffer:
                    buffer.pop()
                    sys.stdout.write("\b \b")
                    sys.stdout.flush()
            elif char.isprintable():
                buffer.append(char)
                sys.stdout.write(char)
                sys.stdout.flush()
    while True:
        if select.select([sys.stdin], [], [], 0)[0]:
            line = sys.stdin.readline()
            if line == "":
                raise ExitRequested
            return line.rstrip("\r\n")
        await asyncio.sleep(0.05)


async def pause(message: str = "Press Enter to return to the menu...") -> None:
    await read_line(f"\n{DIM}{message}{RESET} ")


# --------------------------------------------------------------------- alarm
def alarm(seconds: float = 4.0) -> None:
    """Audible alert (Windows beeps; terminal bell elsewhere). Runs in a worker thread."""
    end = time.time() + seconds
    try:
        import winsound
        while time.time() < end:
            for frequency in (1000, 1500, 1000, 1500):
                winsound.Beep(frequency, 200)
    except ImportError:
        while time.time() < end:
            sys.stdout.write("\a")
            sys.stdout.flush()
            time.sleep(0.6)
