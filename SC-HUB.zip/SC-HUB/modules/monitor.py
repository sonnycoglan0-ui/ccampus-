"""Video detection (page + accessible embedded frames) and shared runtime state."""
from __future__ import annotations

import logging
import re
import time
from collections import deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

log = logging.getLogger("sc_hub.monitor")

# Runs inside every frame: reports every <video> plus a heading / title for naming.
JS_SCAN = """() => {
  const headingEl = document.querySelector(
    'h1, h2, [class*="lesson-title" i], [class*="video-title" i], [class*="topic-title" i]');
  const heading = headingEl && headingEl.innerText ? headingEl.innerText.trim().slice(0, 120) : '';
  const videos = [...document.querySelectorAll('video')].map((v, i) => {
    const r = v.getBoundingClientRect();
    const cs = getComputedStyle(v);
    const shown = r.width > 0 && r.height > 0 && cs.visibility !== 'hidden' && cs.display !== 'none';
    return {
      index: i,
      current: isFinite(v.currentTime) ? v.currentTime : 0,
      duration: isFinite(v.duration) ? v.duration : 0,
      paused: v.paused,
      ended: v.ended,
      ready: v.readyState,
      area: shown ? Math.round(r.width * r.height) : 0,
      label: v.getAttribute('title') || v.getAttribute('aria-label') || v.getAttribute('data-title') || ''
    };
  });
  return { heading: heading, docTitle: document.title || '', videos: videos };
}"""

JS_PLAY = """async (idx) => {
  const v = document.querySelectorAll('video')[idx];
  if (!v) return 'missing';
  if (v.ended || !v.paused) return 'skip';
  const attempt = () => Promise.race([
    v.play(),
    new Promise((_, reject) => setTimeout(() => reject(new Error('timeout')), 4000))
  ]);
  try { await attempt(); return 'played'; }
  catch (e) {
    v.muted = true;
    try { await attempt(); return 'played (muted)'; } catch (e2) { return 'blocked'; }
  }
}"""

PLAY_SELECTOR = (
    ".ytp-large-play-button, .vjs-big-play-button, .plyr__control--overlaid, "
    ".jw-icon-display, button[aria-label*='Play' i], [title='Play']"
)

_GENERIC_TITLE = re.compile(r"^\s*(about:blank|untitled|(youtube|vimeo)?\s*(video\s*)?player)?\s*$", re.I)
_SITE_SUFFIX = re.compile(r"\s*[-|\u2013]\s*(YouTube|Vimeo)\s*$", re.I)


@dataclass
class VideoInfo:
    title: str
    current: float
    duration: float
    status: str  # LOADING / PLAYING / PAUSED / FINISHED
    key: str
    frame: Any = None
    index: int = 0
    frame_url: str = ""
    finished_reads: int = 0
    finished_for: float = 0.0
    is_new: bool = False

    @property
    def percent(self) -> int:
        if self.status == "FINISHED":
            return 100
        if self.duration <= 0:
            return 0
        return max(0, min(100, int(self.current / self.duration * 100)))

    @property
    def finished(self) -> bool:
        return self.status == "FINISHED"

    @property
    def confirmed_finished(self) -> bool:
        """Finished on at least two consecutive reads (protects against flicker/seeks)."""
        return self.finished and self.finished_reads >= 2


@dataclass
class AppState:
    connection: str = "DISCONNECTED"  # DISCONNECTED / CONNECTED / LOGIN REQUIRED / UNAVAILABLE / NO PAGE
    browser: str = "CLOSED"  # CLOSED / RUNNING / CRASHED
    monitoring: bool = False
    auto_continue: bool = False
    page_status: str = "Not connected - use option [1]"
    info: VideoInfo | None = None
    completed: int = 0
    advanced: int = 0
    errors: int = 0
    events: deque = field(default_factory=lambda: deque(maxlen=6))

    def event(self, message: str, level: str = "info") -> None:
        self.events.append((datetime.now(), level, message))


class VideoMonitor:
    def __init__(self) -> None:
        self._key: str | None = None
        self._finished_reads = 0
        self._finished_at: float | None = None
        self._play_attempts: dict[str, int] = {}
        self._last_play_try = 0.0
        self._warned_frames: set[str] = set()
        self.skipped_frames = 0

    def reset(self) -> None:
        self._key = None
        self._finished_reads = 0
        self._finished_at = None

    # ------------------------------------------------------------------ reading
    async def read(self, page: Any, track: bool = True) -> VideoInfo | None:
        """Return info about the main video on the page, or None if there is none.

        track=False reads without touching completion tracking (used by menu actions).
        """
        main = page.main_frame
        candidates: list[tuple[Any, dict, dict]] = []
        main_heading = ""
        main_title = ""
        skipped = 0
        for frame in list(page.frames):
            try:
                data = await frame.evaluate(JS_SCAN)
            except Exception as exc:  # detached / navigating / inaccessible frame
                skipped += 1
                self._warn_frame(frame, exc)
                continue
            if frame == main:
                main_heading = data.get("heading", "")
                main_title = data.get("docTitle", "")
            for video in data.get("videos", []):
                candidates.append((frame, data, video))
        self.skipped_frames = skipped
        if not candidates:
            return None

        visible = [c for c in candidates if c[2]["area"] > 0]
        pool = visible or [c for c in candidates if c[2]["duration"] > 0]
        if not pool:
            return None
        frame, data, video = max(pool, key=lambda c: (c[2]["area"], c[2]["duration"]))

        title = self._pick_title(video, frame == main, data, main_heading, main_title)
        duration = float(video["duration"])
        current = float(video["current"])
        finished = bool(video["ended"]) or (duration > 0 and current >= duration - 0.5)
        if duration <= 0:
            status = "LOADING"
        elif finished:
            status = "FINISHED"
        elif video["paused"]:
            status = "PAUSED"
        else:
            status = "PLAYING"

        key = f"{frame.url}|{title}|{round(duration)}" if duration > 0 else f"{frame.url}|{title}"
        now = time.monotonic()
        is_new = False
        if track:
            if key != self._key:
                self._key = key
                self._finished_reads = 0
                self._finished_at = None
                self._play_attempts.clear()
                is_new = True
            if finished:
                self._finished_reads += 1
                if self._finished_at is None:
                    self._finished_at = now
            else:
                self._finished_reads = 0
                self._finished_at = None
        same = key == self._key
        return VideoInfo(
            title=title,
            current=current,
            duration=duration,
            status=status,
            key=key,
            frame=frame,
            index=int(video["index"]),
            frame_url=frame.url,
            finished_reads=self._finished_reads if same else 0,
            finished_for=(now - self._finished_at) if (same and finished and self._finished_at) else 0.0,
            is_new=is_new,
        )

    @staticmethod
    def _clean(text: str | None) -> str:
        text = _SITE_SUFFIX.sub("", (text or "").strip())
        return "" if _GENERIC_TITLE.match(text) else text[:80]

    def _pick_title(self, video: dict, is_main: bool, data: dict, main_heading: str, main_title: str) -> str:
        options = [video.get("label")]
        if not is_main:
            options.append(data.get("docTitle"))
        options += [main_heading, main_title]
        for option in options:
            cleaned = self._clean(option)
            if cleaned:
                return cleaned
        return "Untitled video"

    def _warn_frame(self, frame: Any, exc: Exception) -> None:
        url = getattr(frame, "url", "?")
        if url not in self._warned_frames:
            self._warned_frames.add(url)
            if len(self._warned_frames) > 100:
                self._warned_frames.clear()
            log.debug("Embedded frame not readable (%s): %s", url, str(exc).splitlines()[0] if str(exc) else exc)

    # ---------------------------------------------------------------- auto-play
    async def ensure_playing(self, info: VideoInfo) -> str | None:
        """Start a paused, unfinished video (max 3 tries per video, 4 s apart)."""
        if info.finished or info.status != "PAUSED" or info.frame is None:
            return None
        tries = self._play_attempts.get(info.key, 0)
        now = time.monotonic()
        if tries >= 3 or now - self._last_play_try < 4:
            return None
        self._play_attempts[info.key] = tries + 1
        self._last_play_try = now
        try:
            result = await info.frame.evaluate(JS_PLAY, info.index)
        except Exception as exc:
            log.debug("Auto-play failed: %s", exc)
            return None
        if result == "blocked":
            try:
                await info.frame.locator(PLAY_SELECTOR).first.click(timeout=1500)
                result = "blocked - clicked the player's play button"
            except Exception:
                result = "blocked by the browser - press play once manually"
        return result if result != "skip" else None
