"""Navigation controls: find Next / Continue / Finish Topic and click them safely."""
from __future__ import annotations

import asyncio
import logging
import re
import time
from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from .settings import Settings

log = logging.getLogger("sc_hub.navigation")

NAV_PATTERN = re.compile(
    r"^\s*(next(\s+(lesson|topic|video|step|page|lecture|chapter))?|continue|finish\s+topic)\s*[\u2192>\u00bb\u203a]*\s*$",
    re.I,
)
MIN_CLICK_INTERVAL = 4.0  # seconds between any two clicks

JS_SIGNATURE = """() => {
  const h = document.querySelector('h1, h2');
  const media = [...document.querySelectorAll('video, iframe')]
    .map(e => e.currentSrc || e.src || '').join('|');
  return [location.href, document.title, h && h.innerText ? h.innerText.trim() : '', media].join('||');
}"""

Reader = Callable[..., Awaitable[Any]]


@dataclass
class NavControl:
    element: Any
    label: str
    frame_url: str


@dataclass
class NavResult:
    code: str  # ok / unconfirmed / click_failed / no_button / blocked
    message: str
    label: str = ""

    @property
    def clicked(self) -> bool:
        return self.code in ("ok", "unconfirmed", "click_failed")

    @property
    def ok(self) -> bool:
        return self.code == "ok"


class Navigator:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self._lock = asyncio.Lock()
        self._last_click = 0.0
        self._seen_key: str | None = None
        self._attempted_key: str | None = None

    # -------------------------------------------------------- duplicate guards
    def note_key(self, key: str | None) -> None:
        """Call every tick with the current video key; a new video clears the click guard."""
        if key != self._seen_key:
            self._seen_key = key
            self._attempted_key = None

    def already_attempted(self, key: str) -> bool:
        return key == self._attempted_key

    # ----------------------------------------------------------------- finding
    async def find_control(self, page: Any) -> NavControl | None:
        """First visible, enabled Next/Continue/Finish Topic control in the page or its frames."""
        main = page.main_frame
        frames = [main] + [f for f in page.frames if f != main]
        custom = self.settings.custom_next_selector.strip()
        for frame in frames:
            locators = []
            if custom:
                locators.append(frame.locator(custom))
            locators.append(frame.get_by_role("button", name=NAV_PATTERN))
            locators.append(frame.get_by_role("link", name=NAV_PATTERN))
            for locator in locators:
                try:
                    count = await locator.count()
                except Exception as exc:
                    log.debug("Control search failed in %s: %s", frame.url, exc)
                    continue
                for i in range(min(count, 6)):
                    element = locator.nth(i)
                    try:
                        if not await element.is_visible() or not await element.is_enabled():
                            continue
                        if (await element.get_attribute("aria-disabled")) == "true":
                            continue
                        label = ((await element.inner_text()) or (await element.get_attribute("aria-label")) or "Next")
                        return NavControl(element, " ".join(label.split())[:40], frame.url)
                    except Exception:
                        continue
        return None

    async def signature(self, page: Any) -> str:
        try:
            return await page.main_frame.evaluate(JS_SIGNATURE)
        except Exception:
            return "navigating"

    # ---------------------------------------------------------------- clicking
    async def continue_now(self, page: Any, reader: Reader, auto: bool, delay: float = 0.0) -> NavResult:
        """Click Next/Continue only if the current video has genuinely finished.

        auto=True additionally requires confirmed completion, the navigation delay,
        and no earlier click for this same video. Manual calls may also run on pages
        that have no video at all.
        """
        async with self._lock:
            if time.monotonic() - self._last_click < MIN_CLICK_INTERVAL:
                return NavResult("blocked", "A navigation just happened - wait a few seconds.")

            info = await reader(page, track=False)
            if info is not None:
                if not info.finished:
                    return NavResult("blocked", "The current video has not finished yet.")
                if auto:
                    if not info.confirmed_finished or info.finished_for < delay:
                        return NavResult("blocked", "Waiting for the navigation delay.")
                    if self.already_attempted(info.key):
                        return NavResult("blocked", "Already attempted for this video.")
            elif auto:
                return NavResult("blocked", "No video detected.")

            control = await self.find_control(page)
            if control is None:
                return NavResult("no_button", "No Next / Continue / Finish Topic button is available.")

            before = await self.signature(page)
            old_key = info.key if info is not None else None
            self._last_click = time.monotonic()
            if info is not None:
                self._attempted_key = info.key
            try:
                await control.element.click(timeout=4000)
            except Exception as exc:
                reason = (str(exc).strip().splitlines() or [exc.__class__.__name__])[0][:120]
                log.warning("Click on '%s' failed: %s", control.label, reason)
                return NavResult("click_failed", f"Could not click '{control.label}': {reason}", control.label)

            log.info("Clicked '%s' (%s)", control.label, control.frame_url)
            if await self._confirm_loaded(page, reader, before, old_key):
                return NavResult("ok", f"Clicked '{control.label}' - next page loaded.", control.label)
            return NavResult("unconfirmed", f"Clicked '{control.label}' but the page did not change.", control.label)

    async def _confirm_loaded(self, page: Any, reader: Reader, before: str, old_key: str | None,
                              timeout: float = 15.0) -> bool:
        deadline = time.monotonic() + timeout
        while time.monotonic() < deadline:
            await asyncio.sleep(0.5)
            try:
                if page.is_closed():
                    return False
                changed = (await self.signature(page)) != before
                if not changed and old_key is not None:
                    info = await reader(page, track=False)
                    changed = info is not None and info.key != old_key
            except Exception:
                continue
            if changed:
                try:
                    await page.wait_for_load_state("domcontentloaded", timeout=10000)
                except Exception:
                    pass
                return True
        return False
