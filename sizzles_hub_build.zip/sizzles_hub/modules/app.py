import os
import time
import threading
from modules.settings import load_config, save_config, PROFILE_DIR
from modules.terminal import enable_ansi, show_cursor, draw_dashboard, log, clear
from modules.startup import play_startup
from modules.browser import CampusBrowser
from modules.auto_continue import CampusMonitor
from modules.timer import WorkTimer
from modules.ai import ask_local_ai
from modules.alarm import blare_for_four_seconds

def completion_notice():
    print("\a\a\a", end="", flush=True)
    print("\n\n  ✓ WORK SESSION COMPLETE — WELL DONE!")
    try:
        import winsound
        winsound.MessageBeep(winsound.MB_ICONASTERISK)
    except Exception:
        pass

def prompt_int(label, default, minimum=1, maximum=1440):
    raw = input(f"{label} [{default}]: ").strip()
    if not raw:
        return default
    try:
        return max(minimum, min(maximum, int(raw)))
    except ValueError:
        print("Please enter a whole number.")
        return default

def open_browser(browser, config, active_account):
    print("\nChoose account: [1] Account 1  [2] Account 2")
    choice = input("> ").strip()
    account = "account_2" if choice == "2" else "account_1"
    url = config.get("community_campus_url", "").strip()
    if not url:
        url = input("Community Campus URL (blank to open browser only): ").strip()
        if url:
            config["community_campus_url"] = url
            save_config(config)
    browser.open(account, url)
    print(f"\nOpened {account.replace('_', ' ').title()}. Log in manually in the browser.")
    input("Press Enter after login (or immediately to continue monitoring)...")
    return account

def timer_menu(timer):
    while True:
        clear()
        print("WORK SESSION TIMER\n")
        print("Current:", timer.display())
        print("\n[1] Set custom duration  [2] Start  [3] Pause")
        print("[4] Resume  [5] Reset  [B] Back")
        choice = input("\n> ").strip().lower()
        if choice == "1":
            mins = prompt_int("Duration in minutes", 25, 1, 1440)
            timer.set_minutes(mins)
        elif choice == "2":
            timer.start()
        elif choice == "3":
            timer.pause()
        elif choice == "4":
            timer.resume()
        elif choice == "5":
            timer.reset()
        elif choice == "b":
            return

def settings_menu(config):
    while True:
        clear()
        print("SETTINGS\n")
        print(f"[1] Navigation delay: {config['navigation_delay_seconds']} seconds")
        print(f"[2] Auto-Continue: {config['auto_continue']}")
        print(f"[3] Auto-Next: {config['auto_next']}")
        print(f"[4] Early Next (default OFF): {config['early_next']}")
        print(f"[5] Video monitoring: {config['video_monitoring']}")
        print(f"[6] Community Campus URL: {config.get('community_campus_url') or '(not set)'}")
        print("[B] Back")
        c = input("\n> ").strip().lower()
        if c == "1":
            config["navigation_delay_seconds"] = prompt_int("Delay seconds", config["navigation_delay_seconds"], 0, 120)
        elif c == "2":
            config["auto_continue"] = not config["auto_continue"]
        elif c == "3":
            config["auto_next"] = not config["auto_next"]
        elif c == "4":
            config["early_next"] = not config["early_next"]
        elif c == "5":
            config["video_monitoring"] = not config["video_monitoring"]
        elif c == "6":
            config["community_campus_url"] = input("New URL: ").strip()
        elif c == "b":
            save_config(config)
            return

def ai_menu(config):
    clear()
    print("LOCAL AI — OLLAMA / QWEN 2.5 7B\n")
    print("Ask a question manually. Ollama must be installed and running.")
    question = input("\nQuestion: ").strip()
    options_raw = input("Options (separate with |, or leave blank): ").strip()
    options = [x.strip() for x in options_raw.split("|") if x.strip()] if options_raw else None
    print("\nThinking locally...\n")
    answer = ask_local_ai(
        question, options,
        config.get("ollama_model", "qwen2.5:7b"),
        config.get("ollama_url", "http://localhost:11434")
    )
    print(answer)
    input("\nPress Enter to return.")

def main():
    enable_ansi()
    config = load_config()
    play_startup()
    browser = CampusBrowser()
    state = {
        "browser": "Disconnected",
        "account": "None",
        "activity": "Not detected",
        "video": "Waiting",
        "automation": "Idle",
        "timer": "Stopped"
    }
    timer = WorkTimer(on_complete=completion_notice)
    monitor = CampusMonitor(browser, config, state)
    monitor.start()
    try:
        while True:
            state["browser"] = "Connected" if browser.connected() else "Disconnected"
            state["account"] = browser.account or "None"
            state["timer"] = timer.display()
            if browser.connected():
                snap = browser.snapshot()
                state["activity"] = snap.get("title") or snap.get("url") or "Open activity"
            draw_dashboard(state)
            choice = input("> ").strip().lower()
            if choice == "1":
                try:
                    account = open_browser(browser, config, browser.account)
                    state["account"] = account
                except Exception as exc:
                    print(f"Browser error: {exc}")
                    log(f"Browser launch error: {exc}")
                    input("Press Enter to continue.")
            elif choice == "2":
                try:
                    account = open_browser(browser, config, browser.account)
                    state["account"] = account
                except Exception as exc:
                    print(f"Account switch error: {exc}")
                    input("Press Enter to continue.")
            elif choice == "3":
                ai_menu(config)
            elif choice == "4":
                timer_menu(timer)
            elif choice == "5":
                settings_menu(config)
                monitor.config = config
            elif choice == "6":
                clear()
                snap = browser.snapshot()
                print("CURRENT PAGE\n")
                print("Title:", snap.get("title"))
                print("URL:", snap.get("url"))
                print("\nVisible page text:\n")
                print((snap.get("text") or "(none)")[:5000])
                input("\nPress Enter to return.")
            elif choice == "q":
                break
    except KeyboardInterrupt:
        pass
    finally:
        monitor.stop()
        browser.close()
        show_cursor()
        clear()
        print("Sizzles Hub closed. Logs saved in /logs.")
