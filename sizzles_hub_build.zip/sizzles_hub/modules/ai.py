import requests

def ask_local_ai(question, options=None, model="qwen2.5:7b",
                 base_url="http://localhost:11434"):
    if not question.strip():
        return "Please enter a question."
    option_text = ""
    if options:
        option_text = "\nAnswer options:\n" + "\n".join(f"- {x}" for x in options)
    prompt = (
        "You are a clear, supportive study assistant. Help the student understand "
        "the question and explain the reasoning. Do not claim certainty when unsure. "
        "Do not submit answers or interact with the learning platform.\n\n"
        f"Question: {question}{option_text}\n\n"
        "Give a concise answer followed by a short explanation."
    )
    try:
        response = requests.post(
            base_url.rstrip("/") + "/api/generate",
            json={"model": model, "prompt": prompt, "stream": False},
            timeout=120
        )
        response.raise_for_status()
        return response.json().get("response", "The local model returned no response.")
    except requests.exceptions.ConnectionError:
        return "Ollama is not running. Start Ollama, then run: ollama pull qwen2.5:7b"
    except requests.RequestException as exc:
        return f"Local AI request failed: {exc}"
