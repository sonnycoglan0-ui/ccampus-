import os
import sys
import shutil
from datetime import datetime

RED = "\033[91m"
CYAN = "\033[96m"
WHITE = "\033[97m"
DIM = "\033[90m"
RESET = "\033[0m"
BOLD = "\033[1m"

def enable_ansi():
    if os.name == "nt":
        os.system("")
    sys.stdout.write("\033[?25l")
    sys.stdout.flush()

def show_cursor():
    sys.stdout.write("\033[?25h")
    sys.stdout.flush()

def clear():
    sys.stdout.write("\033[2J\033[H")
    sys.stdout.flush()

def log(message):
    from modules.settings import LOG_DIR
    LOG_DIR.mkdir(exist_ok=True)
    stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    with (LOG_DIR / "sizzles_hub.log").open("a", encoding="utf-8") as f:
        f.write(f"[{stamp}] {message}\n")

def draw_dashboard(state):
    clear()
    width = min(shutil.get_terminal_size((90, 28)).columns, 100)
    line = "═" * max(40, width - 2)
    print(f"{CYAN}{BOLD}╔{line}╗{RESET}")
    print(f"{CYAN}{BOLD}║{'S I Z Z L E S   H U B'.center(len(line))}║{RESET}")
    print(f"{CYAN}{BOLD}╚{line}╝{RESET}")
    print(f"{DIM}community campus command centre  •  {datetime.now():%d %b %Y  %H:%M:%S}{RESET}")
    print()
    print(f"{RED}SYSTEM STATUS{RESET}")
    print(f"  Browser: {state.get('browser', 'Disconnected')}")
    print(f"  Active account: {state.get('account', 'None')}")
    print(f"  Activity: {state.get('activity', 'Not detected')}")
    print(f"  Video: {state.get('video', 'Waiting')}")
    print(f"  Automation: {state.get('automation', 'Idle')}")
    print(f"  Work timer: {state.get('timer', 'Stopped')}")
    print()
    print(f"{CYAN}COMMANDS{RESET}")
    print("  [1] Open / reconnect Community Campus")
    print("  [2] Switch account")
    print("  [3] Ask local AI")
    print("  [4] Work timer")
    print("  [5] Settings")
    print("  [6] Show current page / activity status")
    print("  [Q] Quit")
    print()
    print(f"{DIM}Choose a command. Dashboard refreshes in place.{RESET}")
